"use client";

import { useMemo, useState } from "react";
import {
  AlertTriangle, Archive, ArrowLeft, ArrowUpRight, Bell, BookOpen, Bookmark,
  CalendarDays, Check, CheckCircle2,
  ChevronDown, ChevronRight, Circle, Clock3, FolderKanban, Goal, Heart,
  LayoutDashboard, Leaf, ListChecks, Lock, Menu, MessageCircle, MoreHorizontal,
  Plus, Search, Settings, ShieldCheck, Sparkles, Target, TrendingUp, Users, X
} from "lucide-react";
import { libraryCategories, libraryContent, libraryStats } from "./libraryContent";

const nav = [
  ["Today", LayoutDashboard], ["Goals & habits", Target], ["Community", Users],
  ["Messages", MessageCircle, "3"], ["Projects", FolderKanban], ["Library", BookOpen],
];

const goals = [
  { title: "Build a £25k monthly sales pipeline", area: "BUSINESS", progress: 48, date: "30 Sep", color: "coral" },
  { title: "Trade 90 days without breaking risk rules", area: "TRADING", progress: 61, date: "31 Oct", color: "green" },
  { title: "Deadlift twice my bodyweight", area: "FITNESS", progress: 72, date: "16 Nov", color: "gold" },
];

const baseHabits = [
  { id: 1, label: "Review plan before market open", meta: "9 day streak", icon: "↗", done: true },
  { id: 2, label: "Complete the day’s training", meta: "4 day streak", icon: "◆", done: false },
  { id: 3, label: "10 quality sales conversations", meta: "7 day streak", icon: "＋", done: true },
];

const pages = {
  "Goals & habits": { eyebrow: "MOMENTUM SYSTEM", title: "Goals & standards", text: "Choose the direction. Build the rhythm. Keep moving when motivation disappears." },
  Community: { eyebrow: "THE NETWORK", title: "Network rooms", text: "High-trust conversations with people who sharpen your thinking and widen what is possible." },
  Messages: { eyebrow: "PRIVATE CHANNELS", title: "Direct messages", text: "Private conversations for honest feedback, useful introductions and real accountability." },
  Projects: { eyebrow: "BUILD TOGETHER", title: "Project workspaces", text: "Invitation-only teams for turning ideas into work that moves." },
  Library: { eyebrow: "COLLECTIVE PLAYBOOK", title: "Knowledge base", text: "Frameworks, lessons and proven practices collected by the network." },
  Admin: { eyebrow: "OPERATIONS", title: "Network operations", text: "Protect the standard. Manage access, rooms, roles and community integrity." },
  Settings: { eyebrow: "YOUR CONTROL", title: "Settings & privacy", text: "Control what you share, where you appear and how Motion Only keeps you informed." },
};

function Sidebar({ active, setActive, open, setOpen }) {
  return (
    <>
      {open && <button className="scrim" onClick={() => setOpen(false)} aria-label="Close menu" />}
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="brand">
          <div className="brandmark"><img src="/motion-only-logo-dark.png" alt="" /></div>
          <div><strong>MOTION <b>ONLY</b></strong><span>CONNECT · BUILD · ADVANCE</span></div>
          <button className="close-mobile" onClick={() => setOpen(false)}><X size={20}/></button>
        </div>
        <p className="nav-label">YOUR MOMENTUM</p>
        <nav>
          {nav.map(([label, Icon, badge]) => (
            <button key={label} className={active === label ? "active" : ""} onClick={() => {setActive(label);setOpen(false)}}>
              <Icon size={18}/><span>{label}</span>{badge && <i>{badge}</i>}
            </button>
          ))}
        </nav>
        <div className="nav-bottom">
          <p className="nav-label">OPERATIONS</p>
          <button className={active === "Admin" ? "active" : ""} onClick={() => {setActive("Admin");setOpen(false)}}>
            <ShieldCheck size={18}/><span>Operations</span>
          </button>
          <button className={active === "Settings" ? "active" : ""} onClick={() => {setActive("Settings");setOpen(false)}}><Settings size={18}/><span>Settings & privacy</span></button>
        </div>
        <div className="profile-mini">
          <div className="avatar">JG</div>
          <div><strong>Joel Gilbert</strong><span>Member since May</span></div>
          <MoreHorizontal size={18}/>
        </div>
      </aside>
    </>
  );
}

function Topbar({ setOpen, notifications, setNotifications }) {
  return (
    <header className="topbar">
      <button className="menu" onClick={() => setOpen(true)}><Menu size={21}/></button>
      <div className="search"><Search size={18}/><input aria-label="Search" placeholder="Search your space…" /><kbd>⌘ K</kbd></div>
      <div className="top-actions">
        <div className="privacy-pill"><Lock size={13}/> Members only · private by default</div>
        <button className="icon-button bell" onClick={() => setNotifications(!notifications)} aria-label="Notifications"><Bell size={19}/><span/></button>
        <button className="avatar top-avatar">JG</button>
      </div>
      {notifications && (
        <div className="notification-pop">
          <div className="pop-head"><strong>Notifications</strong><button onClick={() => setNotifications(false)}><X size={17}/></button></div>
          <div className="notice"><div className="notice-icon"><MessageCircle size={17}/></div><p><strong>Marcus replied in The Trading Floor</strong><span>“Your invalidation level is clean…” · 12m</span></p></div>
          <div className="notice"><div className="notice-icon coral-bg"><Users size={17}/></div><p><strong>You’re invited to Pipeline Sprint</strong><span>A private project by Theo · 2h</span></p></div>
          <button className="view-all">View all notifications</button>
        </div>
      )}
    </header>
  );
}

function WeekStrip() {
  const days = [["MON","20",true],["TUE","21",true],["WED","22",true],["THU","23",false],["TODAY","24",null],["SAT","25",null],["SUN","26",null]];
  return <div className="week-strip">{days.map(([d,n,s]) => <div className={d==="TODAY" ? "today" : ""} key={d}><span>{d}</span><strong>{n}</strong>{s===true?<Check size={12}/>:s===false?<i/>:<em/>}</div>)}</div>
}

function Home({ habits, toggleHabit, toast }) {
  const completed = habits.filter(h => h.done).length;
  return (
    <>
      <section className="welcome">
        <div><p className="eyebrow">FRIDAY, 24 JULY · DAY 47 IN MOTION</p><h1>Momentum is earned.</h1><p>Move with intent. Build with others. Keep the promise.</p></div>
        <button className="primary" onClick={() => toast("Your private daily reset is ready.")}><ArrowUpRight size={16}/> Set today’s motion</button>
      </section>
      <WeekStrip/>
      <div className="dashboard-grid">
        <main>
          <section className="card focus-card">
            <div className="section-head"><div><p className="eyebrow">TODAY’S MOTION</p><h2>Three moves that matter</h2></div><button className="link-btn" onClick={() => toast("Move added to today.")}><Plus size={15}/> Add a move</button></div>
            <div className="commitment">
              <button className="round-check" onClick={() => toast("Commitment completed. Nicely done.")}><Circle size={21}/></button>
              <div><strong>Review the London session watchlist before 7:30</strong><span><Clock3 size={13}/> This morning · Trading system</span></div><button><MoreHorizontal size={18}/></button>
            </div>
            <div className="commitment">
              <button className="round-check done"><CheckCircle2 size={21}/></button>
              <div><strong>Complete upper body strength + Zone 2</strong><span><Check size={13}/> Completed at 12:40 · Fitness</span></div><button><MoreHorizontal size={18}/></button>
            </div>
            <div className="commitment">
              <button className="round-check"><Circle size={21}/></button>
              <div><strong>Send the new offer deck to five qualified prospects</strong><span><Clock3 size={13}/> Before 5pm · Sales pipeline</span></div><button><MoreHorizontal size={18}/></button>
            </div>
            <div className="focus-foot"><div><span>{completed + 1} of 5 complete</span><div className="mini-progress"><i style={{width:`${(completed+1)*20}%`}}/></div></div><p><Lock size={12}/> Only visible to you</p></div>
          </section>

          <section className="goals-section">
            <div className="section-head"><div><p className="eyebrow">FORWARD PATH</p><h2>Goals in motion</h2></div><button className="link-btn">View all <ArrowUpRight size={15}/></button></div>
            <div className="goal-grid">
              {goals.map(g => <article className="goal-card" key={g.title}>
                <div className={`goal-icon ${g.color}`}><Goal size={18}/></div>
                <button><MoreHorizontal size={17}/></button><p className="goal-area">{g.area}</p><h3>{g.title}</h3>
                <div className="goal-progress"><i style={{width:`${g.progress}%`}} className={g.color}/></div>
                <div className="goal-meta"><strong>{g.progress}%</strong><span><CalendarDays size={12}/>{g.date}</span></div>
              </article>)}
            </div>
          </section>
        </main>
        <aside className="right-rail">
          <section className="card habits">
            <div className="section-head"><div><p className="eyebrow">CONSISTENCY ENGINE</p><h2>Daily standards</h2></div><button><ChevronRight size={18}/></button></div>
            {habits.map(h => <button className="habit" key={h.id} onClick={() => toggleHabit(h.id)}>
              <span className="habit-symbol">{h.icon}</span><div><strong>{h.label}</strong><span>{h.meta}</span></div>
              <i className={h.done ? "checked" : ""}>{h.done && <Check size={13}/>}</i>
            </button>)}
            <button className="add-habit" onClick={() => toast("Discipline builder opened.")}><Plus size={15}/> Add a discipline</button>
          </section>
          <section className="card pulse">
            <p className="eyebrow">MOMENTUM INDEX</p><div className="pulse-top"><div className="ring"><span>74<small>%</small></span></div><div><h3>You kept<br/>moving.</h3><p>+8% from last week</p></div></div>
            <div className="stat-row"><span>Commitments kept<strong>14 <small>/ 18</small></strong></span><span>Habit check-ins<strong>17 <small>/ 21</small></strong></span></div>
            <button className="soft-btn" onClick={() => toast("Your weekly debrief is ready.")}>Open weekly debrief <ChevronRight size={15}/></button>
          </section>
          <section className="card community-card">
            <div className="room-photo"><div className="photo-shape one"/><div className="photo-shape two"/><span><Users size={16}/> 8 active now</span></div>
            <div className="room-body"><p className="eyebrow">FROM THE NETWORK</p><h3>Which rule protected your capital this week?</h3><p>In <strong>The Trading Floor</strong> · 23 replies</p><div><div className="avatar-stack"><i>MK</i><i>TS</i><i>+9</i></div><button onClick={() => toast("Opening the conversation…")}>Enter the room <ArrowUpRight size={14}/></button></div></div>
          </section>
        </aside>
      </div>
    </>
  );
}

const libraryCategoryIcons = {
  Foundations: Sparkles,
  Business: FolderKanban,
  Trading: TrendingUp,
  Fitness: Heart,
};

function LibraryReader({ resource, onBack, onNext, saved, toggleSaved, toast }) {
  const [checked, setChecked] = useState([]);
  const markCheck = (index) => setChecked((current) =>
    current.includes(index) ? current.filter((item) => item !== index) : [...current, index]
  );
  const CategoryIcon = libraryCategoryIcons[resource.category] || BookOpen;

  return (
    <article className="library-reader">
      <div className="reader-actions">
        <button className="reader-back" onClick={onBack}><ArrowLeft size={16}/> Back to library</button>
        <button className={`save-resource ${saved ? "saved" : ""}`} onClick={toggleSaved}>
          <Bookmark size={15} fill={saved ? "currentColor" : "none"}/>{saved ? "Saved" : "Save"}
        </button>
      </div>

      <header className="reader-hero">
        <div className="reader-category"><CategoryIcon size={16}/>{resource.category} / {resource.type}</div>
        <h1>{resource.title}</h1>
        <p>{resource.summary}</p>
        <div className="reader-meta">
          <span><Clock3 size={13}/>{resource.minutes} min</span>
          <span><Target size={13}/>{resource.level}</span>
          <span><Lock size={13}/>Private progress</span>
        </div>
        <div className="reader-outcome"><span>YOU WILL LEAVE WITH</span><strong>{resource.outcome}</strong></div>
      </header>

      {resource.safety && (
        <div className="reader-safety">
          <AlertTriangle size={19}/>
          <div><strong>Read this first</strong><p>{resource.safety}</p></div>
        </div>
      )}

      <div className="reader-layout">
        <div className="reader-body">
          {resource.sections.map((section, sectionIndex) => (
            <section className="reader-section" id={`${resource.id}-${sectionIndex}`} key={section.heading}>
              <span className="section-number">{String(sectionIndex + 1).padStart(2, "0")}</span>
              <h2>{section.heading}</h2>
              {section.body?.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
              {section.steps && (
                <ol className="reader-steps">
                  {section.steps.map((step, index) => <li key={step}><i>{index + 1}</i><span>{step}</span></li>)}
                </ol>
              )}
              {section.bullets && (
                <ul className="reader-bullets">
                  {section.bullets.map((bullet) => <li key={bullet}><ChevronRight size={14}/><span>{bullet}</span></li>)}
                </ul>
              )}
              {section.table && (
                <div className="reader-table-wrap">
                  <table className="reader-table">
                    <thead><tr>{section.table.headers.map((header) => <th key={header}>{header}</th>)}</tr></thead>
                    <tbody>{section.table.rows.map((row) => <tr key={row.join("-")}>{row.map((cell) => <td key={cell}>{cell}</td>)}</tr>)}</tbody>
                  </table>
                </div>
              )}
              {section.callout && (
                <div className="reader-callout"><span>{section.callout.label}</span><p>{section.callout.text}</p></div>
              )}
            </section>
          ))}

          <section className="resource-checklist" id="library-checklist">
            <div className="checklist-title">
              <div><p className="eyebrow">ACTION CHECK</p><h2>Ready to use</h2></div>
              <strong>{checked.length} / {resource.checklist.length}</strong>
            </div>
            <div className="checklist-progress"><i style={{width:`${checked.length / resource.checklist.length * 100}%`}}/></div>
            {resource.checklist.map((item, index) => (
              <button className={checked.includes(index) ? "complete" : ""} onClick={() => markCheck(index)} key={item}>
                <i>{checked.includes(index) && <Check size={14}/>}</i><span>{item}</span>
              </button>
            ))}
            <p className="private-note"><Lock size={12}/>Your checks stay on this device and are private to you.</p>
          </section>

          {resource.template && (
            <section className="resource-template">
              <div className="template-head">
                <div><p className="eyebrow">WORKSHEET</p><h2>{resource.template.title}</h2><p>{resource.template.intro}</p></div>
                <button onClick={() => toast(`${resource.template.title} added to your private workspace.`)}><Plus size={14}/>Use template</button>
              </div>
              <div className="template-fields">
                {resource.template.fields.map(([label, prompt], index) => (
                  <div key={label}><i>{String(index + 1).padStart(2, "0")}</i><span><strong>{label}</strong><small>{prompt}</small></span></div>
                ))}
              </div>
            </section>
          )}

          <section className="resource-sources">
            <p className="eyebrow">SOURCE NOTES</p>
            <h2>Read further</h2>
            <p>These references support the guide and provide the fuller official or research context. Motion Only content is educational and should be adapted to your circumstances.</p>
            {resource.sources.length ? (
              <div>{resource.sources.map((source) => (
                <a key={source.url} href={source.url} target="_blank" rel="noreferrer">
                  <span>{source.label}</span><ArrowUpRight size={14}/>
                </a>
              ))}</div>
            ) : <span className="no-sources">Motion Only operating guidance. No external source required.</span>}
          </section>
        </div>

        <aside className="reader-index">
          <p className="eyebrow">IN THIS GUIDE</p>
          {resource.sections.map((section, index) => (
            <a href={`#${resource.id}-${index}`} key={section.heading}><span>{String(index + 1).padStart(2, "0")}</span>{section.heading}</a>
          ))}
          <a href="#library-checklist"><span>✓</span>Action checklist</a>
          <div className="index-standard"><ShieldCheck size={16}/><span><strong>Motion Only standard</strong>Practical, sourced and private by default.</span></div>
        </aside>
      </div>

      <footer className="reader-next">
        <span>NEXT IN {resource.category.toUpperCase()}</span>
        <button onClick={onNext}><strong>Continue the track</strong><ChevronRight size={18}/></button>
      </footer>
    </article>
  );
}

function LibraryPage({ toast }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [selected, setSelected] = useState(null);
  const [saved, setSaved] = useState(["motion-only-operating-system"]);
  const filtered = useMemo(() => libraryContent.filter((item) => {
    const matchesCategory = category === "All" || item.category === category;
    const haystack = `${item.title} ${item.category} ${item.type} ${item.summary} ${item.outcome}`.toLowerCase();
    return matchesCategory && haystack.includes(query.toLowerCase());
  }), [query, category]);

  const openResource = (resource) => {
    setSelected(resource);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const toggleSaved = (id) => {
    setSaved((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };
  const nextResource = () => {
    const track = libraryContent.filter((item) => item.category === selected.category);
    const next = track[(track.findIndex((item) => item.id === selected.id) + 1) % track.length];
    openResource(next);
  };

  if (selected) {
    return <LibraryReader
      key={selected.id}
      resource={selected}
      onBack={() => {setSelected(null); window.scrollTo({ top: 0, behavior: "smooth" });}}
      onNext={nextResource}
      saved={saved.includes(selected.id)}
      toggleSaved={() => toggleSaved(selected.id)}
      toast={toast}
    />;
  }

  return (
    <div className="library-page">
      <section className="library-hero">
        <div>
          <p className="eyebrow">THE MOTION ONLY FIELD LIBRARY</p>
          <h1>Knowledge that moves.</h1>
          <p>Practical systems for building the work, protecting the downside and staying consistent. No hype. No filler. Every guide ends in an action.</p>
        </div>
        <div className="library-stats">
          <span><strong>{libraryStats.resources}</strong>Complete resources</span>
          <span><strong>{libraryStats.tracks}</strong>Focused tracks</span>
          <span><strong>{libraryStats.templates}</strong>Working templates</span>
        </div>
      </section>

      <section className="featured-resources">
        <div className="section-head">
          <div><p className="eyebrow">START WITH THE SYSTEM</p><h2>Core field guides</h2></div>
          <span className="private-library"><Lock size={12}/>Reading activity is private</span>
        </div>
        <div className="featured-grid">
          {libraryContent.filter((item) => item.featured).map((item, index) => {
            const Icon = libraryCategoryIcons[item.category];
            return (
              <button onClick={() => openResource(item)} key={item.id}>
                <span className="featured-number">0{index + 1}</span>
                <i><Icon size={19}/></i>
                <small>{item.category} / {item.minutes} min</small>
                <strong>{item.title}</strong>
                <p>{item.summary}</p>
                <em>Open field guide <ArrowUpRight size={14}/></em>
              </button>
            );
          })}
        </div>
      </section>

      <section className="library-catalogue">
        <div className="catalogue-head">
          <div><p className="eyebrow">COMPLETE LIBRARY</p><h2>Choose the next constraint</h2></div>
          <div className="library-search"><Search size={17}/><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search guides, systems and templates..."/></div>
        </div>
        <div className="category-tabs">
          {libraryCategories.map((item) => (
            <button className={category === item ? "active" : ""} onClick={() => setCategory(item)} key={item}>
              {item}<span>{item === "All" ? libraryContent.length : libraryContent.filter((resource) => resource.category === item).length}</span>
            </button>
          ))}
        </div>
        <div className="catalogue-summary">
          <span>{filtered.length} resources</span>
          <span><ShieldCheck size={13}/>Educational, sourced and private by default</span>
        </div>
        <div className="library-grid">
          {filtered.map((item) => {
            const Icon = libraryCategoryIcons[item.category];
            const isSaved = saved.includes(item.id);
            return (
              <article className="library-card" key={item.id}>
                <div className="library-card-top">
                  <i><Icon size={18}/></i>
                  <button aria-label={isSaved ? "Remove saved resource" : "Save resource"} onClick={() => toggleSaved(item.id)}>
                    <Bookmark size={15} fill={isSaved ? "currentColor" : "none"}/>
                  </button>
                </div>
                <span className="resource-type">{item.category} / {item.type}</span>
                <h3>{item.title}</h3>
                <p>{item.summary}</p>
                <div className="resource-meta"><span><Clock3 size={12}/>{item.minutes} min</span><span>{item.level}</span></div>
                <button className="open-resource" onClick={() => openResource(item)}>Open resource <ArrowUpRight size={14}/></button>
              </article>
            );
          })}
          {!filtered.length && <div className="library-empty"><Search size={24}/><strong>No resources found</strong><span>Try a different search or track.</span></div>}
        </div>
      </section>

      <section className="library-principles">
        <div><ShieldCheck size={21}/><span><strong>Built for responsible progress</strong>Trading education is process-led, fitness guidance includes clear safety boundaries, and business playbooks avoid manipulative claims.</span></div>
        <div><Lock size={21}/><span><strong>Private by default</strong>Your saved resources, worksheet use and completion activity are never shared unless you choose to share them.</span></div>
        <div><ListChecks size={21}/><span><strong>Action at the end</strong>Every resource includes a completion check and a working template, so reading turns into motion.</span></div>
      </section>
    </div>
  );
}

function FeaturePage({ name, toast }) {
  const p = pages[name];
  const featureData = {
    Admin: [
      { title:"Members", meta:"128 active members", Icon:Users, description:"Manage member access, profile status and individual permissions.", stat:"94% active this month" },
      { title:"Invitations", meta:"7 awaiting response", Icon:Archive, description:"Issue, expire and review private invitations to the network.", stat:"31 accepted this quarter" },
      { title:"Roles & access", meta:"4 permission groups", Icon:ShieldCheck, description:"Control who can create rooms, lead projects and moderate discussions.", stat:"Last reviewed 3 days ago" },
      { title:"Moderation", meta:"2 items to review", Icon:Heart, description:"Review reports and protect the standard of every Motion Only space.", stat:"Median response: 22 min" },
    ],
    Messages: [
      { title:"Marcus Cole", meta:"EUR/USD plan attached · 12m", Icon:MessageCircle, description:"Your invalidation level is clean. I would wait for the sweep before looking for entry.", stat:"2 unread messages" },
      { title:"Priya Shah", meta:"Re: Pipeline Sprint · 1h", Icon:FolderKanban, description:"The new offer deck is much tighter. Send me the five target accounts and I’ll make two introductions.", stat:"Shared project: Pipeline Sprint" },
      { title:"Leo Grant", meta:"Saturday strength session · 3h", Icon:TrendingUp, description:"Heavy compounds at 08:00. I’ve added your working sets and target loads to the session.", stat:"Training partner" },
    ],
    Community: [
      { title:"The Trading Floor", meta:"23 new posts · 18 active", Icon:TrendingUp, description:"Setups, execution reviews and risk conversations. No signals, no hype—process first.", stat:"482 members" },
      { title:"Business Builders", meta:"11 new posts · 9 active", Icon:Users, description:"Offers, sales, operations and accountability for members building serious businesses.", stat:"316 members" },
      { title:"Performance Room", meta:"7 new posts · 12 active", Icon:Heart, description:"Strength, conditioning, nutrition and recovery for sustainable high performance.", stat:"279 members" },
    ],
    Projects: [
      { title:"90-Day Risk Discipline", meta:"6 members · Private", Icon:Target, description:"A private accountability sprint built around flawless risk execution and weekly reviews.", stat:"Day 34 of 90" },
      { title:"£25k Pipeline Sprint", meta:"4 members · Private", Icon:FolderKanban, description:"Build a qualified £25k monthly pipeline through daily outreach, referrals and offer refinement.", stat:"£12.4k qualified" },
      { title:"12-Week Strength Standard", meta:"8 members · Invitation only", Icon:TrendingUp, description:"Shared programming, weekly heavy sessions and accountability toward individual strength standards.", stat:"Week 5 of 12" },
    ],
    "Goals & habits": [
      ...goals.map(g => ({ title:g.title, meta:`${g.progress}% complete · ${g.date}`, Icon:Target, description:`A private ${g.area.toLowerCase()} goal with measurable weekly actions and progress reviews.`, stat:`${g.progress}% momentum` })),
      ...baseHabits.map(h => ({ title:h.label, meta:h.meta, Icon:TrendingUp, description:"A daily standard tracked privately. Check in honestly and protect the streak by returning quickly.", stat:h.done ? "Complete today" : "Due today" })),
    ],
    Library: [
      { title:"The 1% Risk Playbook", meta:"Trading · 8 min read", Icon:TrendingUp, description:"Position sizing, daily loss limits and the review questions that keep capital protected.", stat:"Saved by 184 members" },
      { title:"Build an Offer People Understand", meta:"Business · 12 min read", Icon:BookOpen, description:"A practical framework for clarifying the problem, promise, proof and path in your offer.", stat:"Saved by 129 members" },
      { title:"12-Week Strength & Conditioning Block", meta:"Fitness · Programme", Icon:Heart, description:"Progressive strength, conditioning and recovery for members building durable performance.", stat:"67 members following" },
    ],
    Settings: [
      { title:"Privacy defaults", meta:"Everything private by default", Icon:Lock, description:"Goals, progress, trading notes, project content and evidence stay private until you explicitly share them.", stat:"Maximum privacy" },
      { title:"Notifications", meta:"Daily summary · Direct messages", Icon:Bell, description:"Choose which activity deserves your attention and keep everything else out of the way.", stat:"2 channels enabled" },
      { title:"Profile visibility", meta:"Visible to members only", Icon:Users, description:"Control which parts of your profile can be discovered by other verified Motion Only members.", stat:"Members only" },
    ],
  };
  const [items, setItems] = useState(featureData[name]);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState("");
  const filtered = useMemo(() => items.filter(item => `${item.title} ${item.meta}`.toLowerCase().includes(query.toLowerCase())), [items, query]);
  const createLabel = name === "Admin" ? "Invite member" : name === "Messages" ? "New message" : name === "Settings" ? "Privacy check" : "Create new";
  const saveNew = (event) => {
    event.preventDefault();
    if (!draft.trim()) return;
    const created = { title:draft.trim(), meta:"Created now · Private", Icon:name === "Messages" ? MessageCircle : Target, description:"A new private Motion Only item. Add collaborators or share it explicitly when you are ready.", stat:"Private to you" };
    setItems([created, ...items]);
    setDraft("");
    setCreating(false);
    setSelected(created);
    toast(`${created.title} created privately.`);
  };
  return <div className="feature-page">
    <div className="feature-hero"><p className="eyebrow">{p.eyebrow}</p><h1>{p.title}</h1><p>{p.text}</p><button className="primary" onClick={() => name === "Settings" ? toast("Privacy check complete. Your content is private by default.") : setCreating(!creating)}>{name === "Settings" ? <ShieldCheck size={16}/> : <Plus size={16}/>} {createLabel}</button></div>
    {creating && name !== "Settings" && <form className="quick-create" onSubmit={saveNew}>
      <div><p className="eyebrow">{createLabel.toUpperCase()}</p><strong>{name === "Admin" ? "Who are you bringing into Motion Only?" : "What are you putting in motion?"}</strong></div>
      <input autoFocus value={draft} onChange={e => setDraft(e.target.value)} placeholder={name === "Messages" ? "Member name…" : "Name it clearly…"} />
      <button type="button" onClick={() => setCreating(false)}>Cancel</button><button type="submit">Save privately</button>
    </form>}
    <div className="feature-toolbar"><div className="search compact"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder={`Search ${name.toLowerCase()}…`}/></div><button className="filter" onClick={() => toast("Showing your private and shared items.")}><Lock size={14}/> Private + shared</button></div>
    <div className={`feature-workspace ${selected ? "has-detail" : ""}`}>
      <div className="feature-list">{filtered.map((item,i)=><button className={`feature-row ${selected?.title === item.title ? "selected" : ""}`} key={item.title} onClick={()=>setSelected(item)}>
        <span className={`feature-icon f${i}`}><item.Icon size={20}/></span><span><strong>{item.title}</strong><small>{item.meta}</small></span><ChevronRight size={18}/>
      </button>)}
      {!filtered.length && <div className="empty-state"><Search size={22}/><strong>No matches</strong><span>Try a broader search.</span></div>}</div>
      {selected && <aside className="detail-panel">
        <button className="detail-close" onClick={() => setSelected(null)} aria-label="Close detail"><X size={17}/></button>
        <span className="detail-icon"><selected.Icon size={22}/></span>
        <p className="eyebrow">PRIVATE DETAIL</p><h2>{selected.title}</h2><p>{selected.description}</p>
        <div className="detail-stat"><span>Current position</span><strong>{selected.stat}</strong></div>
        <div className="detail-privacy"><Lock size={14}/><div><strong>Private by default</strong><span>Only explicit members can access this.</span></div></div>
        <button className="primary detail-action" onClick={() => toast(`${selected.title} is ready.`)}>Open {name === "Messages" ? "conversation" : name === "Community" ? "room" : name === "Admin" ? "controls" : name === "Settings" ? "settings" : "workspace"} <ArrowUpRight size={15}/></button>
      </aside>}
    </div>
  </div>;
}

export default function App() {
  const [active, setActive] = useState("Today");
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState(false);
  const [habits, setHabits] = useState(baseHabits);
  const [toastText, setToastText] = useState("");
  const toast = (text) => { setToastText(text); setTimeout(() => setToastText(""), 2800); };
  const toggleHabit = id => { setHabits(habits.map(h => h.id === id ? {...h, done: !h.done} : h)); toast("Habit check-in saved privately."); };
  return <div className="app-shell">
    <Sidebar active={active} setActive={setActive} open={menuOpen} setOpen={setMenuOpen}/>
    <div className="content-shell">
      <Topbar setOpen={setMenuOpen} notifications={notifications} setNotifications={setNotifications}/>
      <div className="content">{active === "Today"
        ? <Home habits={habits} toggleHabit={toggleHabit} toast={toast}/>
        : active === "Library"
          ? <LibraryPage toast={toast}/>
          : <FeaturePage key={active} name={active} toast={toast}/>}
      </div>
    </div>
    {toastText && <div className="toast"><CheckCircle2 size={17}/>{toastText}</div>}
  </div>;
}
