# Motion Only native app

The iPhone and Android client is built with Expo SDK 57 and React Native.

## Implemented

- Invitation-gated account entry
- Password-first authentication interface with optional magic link
- Guided onboarding and focus selection
- Secure device session storage
- Today, goals, standards, rooms, projects, messages and profile/privacy screens
- Permanent XP, eight levels and level progress
- Weekly 0–100 Momentum bar, stages, countdown, streak, history and bonus projection
- Capped action rewards and weekly review flow
- Working local interactions for the private-beta experience
- API client contract for the Motion Only service
- Internal, preview and production EAS build profiles

## Run

```bash
npm install
npm run typecheck
npm start
```

Set `EXPO_PUBLIC_API_URL` to the deployed API origin before producing a group build.

## Distribution

- `eas build --profile preview --platform android` creates an internally distributed Android APK.
- `eas build --profile preview --platform ios` creates an iOS internal build when Apple credentials are connected.
- Use the production profile for TestFlight, Google Play closed testing and final store releases.
