import * as SecureStore from "expo-secure-store";

const API_URL = process.env.EXPO_PUBLIC_API_URL ?? "http://localhost:4000";
const TOKEN_KEY = "motion-only-api-token";

type RequestOptions = RequestInit & { authenticated?: boolean };

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set("content-type", "application/json");
  if (options.authenticated) {
    const token = await SecureStore.getItemAsync(TOKEN_KEY);
    if (token) headers.set("authorization", `Bearer ${token}`);
  }
  const response = await fetch(`${API_URL}${path}`, { ...options, headers });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message ?? "Motion Only could not complete that request.");
  return payload as T;
}

export async function acceptInvitation(input: { inviteCode: string; email: string; password: string; name: string }) {
  const result = await request<{ token: string; user: { id: string; email: string; role: string } }>("/v1/auth/accept-invite", {
    method: "POST",
    body: JSON.stringify(input)
  });
  await SecureStore.setItemAsync(TOKEN_KEY, result.token);
  return result.user;
}

export async function passwordLogin(email: string, password: string) {
  const result = await request<{ token: string; user: { id: string; email: string; role: string } }>("/v1/auth/password", {
    method: "POST",
    body: JSON.stringify({ email, password })
  });
  await SecureStore.setItemAsync(TOKEN_KEY, result.token);
  return result.user;
}

export function requestMagicLink(email: string) {
  return request<{ accepted: true }>("/v1/auth/magic-link", {
    method: "POST",
    body: JSON.stringify({ email })
  });
}

export function listGoals() {
  return request<{ items: Array<{ id: string; title: string; focus: string; progress: number }> }>("/v1/goals", { authenticated: true });
}

export function getProgression() {
  return request<{
    profile: { lifetime_xp:number; current_level:number; momentum_streak:number; best_momentum_streak:number };
    week: { week_start:string | null; points:number; status:"building" | "secured" | "missed"; bonus_xp:number };
    events: Array<{ event_type:string; xp_points:number; momentum_points:number; occurred_at:string }>;
    history: Array<{ week_start:string; points:number; status:string; bonus_xp:number }>;
    levels: Array<{ level:number; name:string; xp_required:number }>;
  }>("/v1/progression", { authenticated:true });
}

export function submitWeeklyReview(input: { reflection:string; wins:string[]; nextWeekFocus:string }) {
  return request<{ weekStart:string; progression:{ awarded:boolean; lifetime_xp:number; current_level:number; weekly_points:number } }>("/v1/progression/weekly-review", {
    method:"POST",
    authenticated:true,
    body:JSON.stringify(input)
  });
}

export async function logout() {
  await request("/v1/auth/logout", { method: "POST", authenticated: true }).catch(() => undefined);
  await SecureStore.deleteItemAsync(TOKEN_KEY);
}
