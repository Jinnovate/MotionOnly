import React, { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Brand, Eyebrow, GoldButton } from "../components/Primitives";
import { colors } from "../theme";

type Props = {
  onAuthenticated: (email: string) => void;
};

export function AuthScreen({ onAuthenticated }: Props) {
  const [mode, setMode] = useState<"password" | "magic">("password");
  const [invite, setInvite] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [sent, setSent] = useState(false);

  const continueAuth = () => {
    if (invite.trim().length < 6) {
      Alert.alert("Invitation required", "Enter the invitation code from your Motion Only email.");
      return;
    }
    if (!email.includes("@")) {
      Alert.alert("Check your email", "Enter the same email address that received your invitation.");
      return;
    }
    if (mode === "password" && password.length < 8) {
      Alert.alert("Password too short", "Use at least eight characters.");
      return;
    }
    if (mode === "magic") {
      setSent(true);
      return;
    }
    onAuthenticated(email.trim().toLowerCase());
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Brand />
        <View style={styles.hero}>
          <Eyebrow>PRIVATE MEMBERSHIP</Eyebrow>
          <Text style={styles.title}>MOMENTUM{`\n`}STARTS HERE.</Text>
          <Text style={styles.subtitle}>A private network for smart work, disciplined execution and consistent progress.</Text>
        </View>

        <View style={styles.authCard}>
          <View style={styles.lockRow}>
            <Ionicons name="lock-closed" size={15} color={colors.gold} />
            <Text style={styles.lockText}>INVITATION REQUIRED</Text>
          </View>
          <Text style={styles.label}>Invitation code</Text>
          <TextInput value={invite} onChangeText={setInvite} autoCapitalize="characters" placeholder="MO-XXXXXX" placeholderTextColor={colors.mutedDark} style={styles.input} />
          <Text style={styles.label}>Email address</Text>
          <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" placeholder="you@example.com" placeholderTextColor={colors.mutedDark} style={styles.input} />

          <View style={styles.modeSwitch}>
            <Pressable onPress={() => { setMode("password"); setSent(false); }} style={[styles.mode, mode === "password" && styles.modeActive]}>
              <Text style={[styles.modeText, mode === "password" && styles.modeTextActive]}>PASSWORD</Text>
            </Pressable>
            <Pressable onPress={() => { setMode("magic"); setSent(false); }} style={[styles.mode, mode === "magic" && styles.modeActive]}>
              <Text style={[styles.modeText, mode === "magic" && styles.modeTextActive]}>MAGIC LINK</Text>
            </Pressable>
          </View>

          {mode === "password" ? (
            <>
              <Text style={styles.label}>Password</Text>
              <TextInput value={password} onChangeText={setPassword} secureTextEntry autoComplete="password" placeholder="Minimum 8 characters" placeholderTextColor={colors.mutedDark} style={styles.input} />
            </>
          ) : (
            <View style={styles.magicInfo}>
              <Ionicons name="mail-outline" size={18} color={colors.gold} />
              <Text style={styles.magicText}>We’ll send a single-use sign-in link to your invited email address.</Text>
            </View>
          )}

          {sent ? (
            <View style={styles.sent}>
              <Ionicons name="checkmark-circle" size={22} color={colors.green} />
              <View style={{ flex: 1 }}>
                <Text style={styles.sentTitle}>CHECK YOUR EMAIL</Text>
                <Text style={styles.sentText}>The secure link expires in 15 minutes.</Text>
              </View>
              <Pressable onPress={() => onAuthenticated(email.trim().toLowerCase())}><Text style={styles.demoLink}>OPEN DEMO</Text></Pressable>
            </View>
          ) : (
            <GoldButton label={mode === "password" ? "Create secure account" : "Send magic link"} onPress={continueAuth} icon={mode === "password" ? "arrow-forward" : "mail"} />
          )}
          <Text style={styles.privacy}>Your membership, goals, trading activity and progress are private by default.</Text>
        </View>
        <Text style={styles.footer}>MOTION ONLY · CONNECT · BUILD · ADVANCE</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.black },
  content: { flexGrow: 1, paddingHorizontal: 24, paddingTop: 62, paddingBottom: 35 },
  hero: { marginTop: 58, marginBottom: 28, borderLeftWidth: 3, borderLeftColor: colors.gold, paddingLeft: 18 },
  title: { color: colors.text, fontSize: 44, lineHeight: 41, fontWeight: "900", fontStyle: "italic", letterSpacing: -.6 },
  subtitle: { color: colors.muted, fontSize: 12, lineHeight: 19, marginTop: 13, maxWidth: 330 },
  authCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, padding: 18, gap: 9 },
  lockRow: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 5 },
  lockText: { color: colors.textSoft, fontSize: 9, letterSpacing: 1.2, fontWeight: "800" },
  label: { color: colors.muted, fontSize: 9, letterSpacing: .8, textTransform: "uppercase", fontWeight: "700", marginTop: 5 },
  input: { minHeight: 46, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.lineStrong, color: colors.text, paddingHorizontal: 13, fontSize: 13 },
  modeSwitch: { flexDirection: "row", padding: 3, backgroundColor: colors.background, marginVertical: 7 },
  mode: { flex: 1, paddingVertical: 9, alignItems: "center" },
  modeActive: { backgroundColor: colors.raised },
  modeText: { color: colors.muted, fontSize: 9, fontWeight: "800", letterSpacing: .7 },
  modeTextActive: { color: colors.gold },
  magicInfo: { minHeight: 60, flexDirection: "row", alignItems: "center", gap: 11, borderWidth: 1, borderColor: colors.line, padding: 13, marginBottom: 5 },
  magicText: { color: colors.muted, fontSize: 10, lineHeight: 15, flex: 1 },
  sent: { minHeight: 54, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "#111A14", borderWidth: 1, borderColor: "#263D2D", padding: 12 },
  sentTitle: { color: colors.text, fontWeight: "800", fontSize: 10, letterSpacing: .8 },
  sentText: { color: colors.muted, fontSize: 9, marginTop: 2 },
  demoLink: { color: colors.gold, fontSize: 8, fontWeight: "900", letterSpacing: .7 },
  privacy: { color: colors.mutedDark, fontSize: 8, lineHeight: 13, textAlign: "center", marginTop: 5 },
  footer: { color: "#3E4244", fontSize: 8, letterSpacing: 1.6, textAlign: "center", marginTop: "auto", paddingTop: 35 }
});
