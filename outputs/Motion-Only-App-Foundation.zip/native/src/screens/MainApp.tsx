import React, { useMemo, useState } from "react";
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Brand, Card, Eyebrow, GoldButton, OutlineButton, ProgressBar } from "../components/Primitives";
import { conversations, Focus, initialGoals, initialMotions, projects, rooms } from "../data";
import { clampMomentum, getLevel, getMomentumStage, LEVELS, MOMENTUM_SOURCES, weeklyMomentumBonus } from "../progression";
import { colors } from "../theme";

type Tab = "today" | "goals" | "momentum" | "network" | "messages" | "profile";
type Props = { name: string; focuses: Focus[]; onLogout: () => void };

const tabs: { id: Tab; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
  { id: "today", label: "Today", icon: "pulse-outline" },
  { id: "goals", label: "Goals", icon: "flag-outline" },
  { id: "momentum", label: "Momentum", icon: "flash-outline" },
  { id: "network", label: "Network", icon: "people-outline" },
  { id: "messages", label: "Messages", icon: "chatbubble-outline" },
  { id: "profile", label: "You", icon: "person-outline" }
];

export function MainApp({ name, focuses, onLogout }: Props) {
  const [tab, setTab] = useState<Tab>("today");
  const [motions, setMotions] = useState(initialMotions);
  const [goals, setGoals] = useState(initialGoals);
  const [xp, setXp] = useState(520);
  const [weeklyMomentum, setWeeklyMomentum] = useState(68);
  const [momentumStreak] = useState(3);
  const [rewardedMotions, setRewardedMotions] = useState<Set<string>>(new Set(["m1"]));
  const [rewardedGoals, setRewardedGoals] = useState<Set<string>>(new Set());
  const [reviewComplete, setReviewComplete] = useState(false);
  const firstName = name.split(" ")[0] || name;

  const toggleMotion = (id: string) => {
    const target = motions.find(item => item.id === id);
    if (target && !target.complete && !rewardedMotions.has(id)) {
      setWeeklyMomentum(value => clampMomentum(value + MOMENTUM_SOURCES.priorityMotion.momentum));
      setXp(value => value + MOMENTUM_SOURCES.priorityMotion.xp);
      setRewardedMotions(current => new Set(current).add(id));
    }
    setMotions(current => current.map(item => item.id === id ? { ...item, complete: !item.complete } : item));
  };
  const nudgeGoal = (id: string) => {
    if (!rewardedGoals.has(id)) {
      setWeeklyMomentum(value => clampMomentum(value + MOMENTUM_SOURCES.goalProgress.momentum));
      setXp(value => value + MOMENTUM_SOURCES.goalProgress.xp);
      setRewardedGoals(current => new Set(current).add(id));
    }
    setGoals(current => current.map(item => item.id === id ? { ...item, progress: Math.min(100, item.progress + 3) } : item));
  };
  const completeReview = () => {
    if (reviewComplete) return;
    setWeeklyMomentum(value => clampMomentum(value + MOMENTUM_SOURCES.weeklyReview.momentum));
    setXp(value => value + MOMENTUM_SOURCES.weeklyReview.xp);
    setReviewComplete(true);
  };
  const completed = motions.filter(item => item.complete).length;
  const momentum = Math.round((completed / motions.length) * 40 + goals.reduce((sum, goal) => sum + goal.progress, 0) / goals.length * .6);

  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <Brand compact />
        <View style={styles.headerCenter}><Text style={styles.headerBrand}>MOTION <Text style={{ color: colors.gold }}>ONLY</Text></Text><Text style={styles.headerSub}>MEMBERS ONLY</Text></View>
        <Pressable style={styles.headerButton} onPress={() => Alert.alert("Notifications", "2 new messages and one project update.")}>
          <Ionicons name="notifications-outline" size={21} color={colors.textSoft}/><View style={styles.dot}/>
        </Pressable>
      </View>

      <View style={{ flex: 1 }}>
        {tab === "today" && <TodayScreen firstName={firstName} motions={motions} goals={goals} momentum={momentum} weeklyMomentum={weeklyMomentum} xp={xp} momentumStreak={momentumStreak} toggleMotion={toggleMotion} openMomentum={() => setTab("momentum")} />}
        {tab === "goals" && <GoalsScreen goals={goals} nudgeGoal={nudgeGoal} />}
        {tab === "momentum" && <MomentumScreen xp={xp} points={weeklyMomentum} streak={momentumStreak} reviewComplete={reviewComplete} completeReview={completeReview} />}
        {tab === "network" && <NetworkScreen />}
        {tab === "messages" && <MessagesScreen />}
        {tab === "profile" && <ProfileScreen name={name} focuses={focuses} xp={xp} onLogout={onLogout} />}
      </View>

      <View style={styles.tabBar}>
        {tabs.map(item => {
          const active = tab === item.id;
          return <Pressable key={item.id} onPress={() => setTab(item.id)} style={styles.tab}>
            <View style={active && styles.tabIconActive}><Ionicons name={item.icon} size={20} color={active ? colors.gold : colors.muted}/>{item.id === "messages" && <View style={styles.messageDot}/>}</View>
            <Text style={[styles.tabLabel, active && styles.tabLabelActive]}>{item.label}</Text>
          </Pressable>;
        })}
      </View>
    </View>
  );
}

function TodayScreen({ firstName, motions, goals, momentum, weeklyMomentum, xp, momentumStreak, toggleMotion, openMomentum }: { firstName: string; motions: typeof initialMotions; goals: typeof initialGoals; momentum: number; weeklyMomentum: number; xp: number; momentumStreak: number; toggleMotion: (id: string) => void; openMomentum: () => void }) {
  const level = getLevel(xp);
  const stage = getMomentumStage(weeklyMomentum);
  return <ScrollView contentContainerStyle={styles.screen}>
    <View style={styles.hero}>
      <Eyebrow>FRIDAY · DAY 47 IN MOTION</Eyebrow>
      <Text style={styles.heroTitle}>MOVE WITH{`\n`}INTENT, {firstName.toUpperCase()}.</Text>
      <Text style={styles.heroText}>Build the day before the day builds you.</Text>
    </View>
    <View style={styles.metricRow}>
      <Card style={styles.metricCard}><Text style={styles.metricValue}>{momentum}</Text><Text style={styles.metricLabel}>MOMENTUM INDEX</Text><Text style={styles.metricDelta}>↑ 8 this week</Text></Card>
      <Card style={styles.metricCard}><Text style={styles.metricValue}>{level.level}</Text><Text style={styles.metricLabel}>{level.name.toUpperCase()}</Text><Text style={styles.metricDelta}>{level.xpToNext} XP to next level</Text></Card>
    </View>
    <Pressable onPress={openMomentum}>
      <Card style={styles.weeklyMomentumCard}>
        <View style={styles.weeklyMomentumTop}><View><Eyebrow>WEEKLY MOMENTUM</Eyebrow><Text style={styles.weeklyMomentumStage}>{stage.name.toUpperCase()}</Text></View><Text style={styles.weeklyMomentumPoints}>{weeklyMomentum}<Text style={styles.weeklyMomentumTotal}>/100</Text></Text></View>
        <View style={styles.momentumTrack}><View style={[styles.momentumFill,{width:`${weeklyMomentum}%`}]} /></View>
        <View style={styles.weeklyMomentumBottom}><Text style={styles.weeklyMomentumHint}>{100-weeklyMomentum} POINTS TO SECURE +{weeklyMomentumBonus(momentumStreak)} MOMENTUM XP</Text><Text style={styles.weeklyMomentumTime}>2D 06H LEFT →</Text></View>
      </Card>
    </Pressable>
    <View style={styles.sectionHead}><View><Eyebrow>TODAY’S MOTION</Eyebrow><Text style={styles.sectionTitle}>MOVES THAT MATTER</Text></View><Text style={styles.sectionCount}>{motions.filter(m => m.complete).length}/{motions.length}</Text></View>
    <Card style={styles.motionCard}>
      {motions.map((motion, index) => <Pressable key={motion.id} onPress={() => toggleMotion(motion.id)} style={[styles.motion, index > 0 && styles.motionBorder]}>
        <View style={[styles.check, motion.complete && styles.checkDone]}>{motion.complete && <Ionicons name="checkmark" size={14} color={colors.black}/>}</View>
        <View style={{ flex: 1 }}><Text style={[styles.motionTitle, motion.complete && styles.motionTitleDone]}>{motion.title}</Text><Text style={styles.motionMeta}>{motion.focus.toUpperCase()} · {motion.meta}</Text></View>
        <Ionicons name="chevron-forward" color={colors.mutedDark} size={17}/>
      </Pressable>)}
    </Card>
    <View style={styles.sectionHead}><View><Eyebrow>FORWARD PATH</Eyebrow><Text style={styles.sectionTitle}>GOALS IN MOTION</Text></View><Pressable><Text style={styles.textLink}>VIEW ALL →</Text></Pressable></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.goalRail}>
      {goals.map((goal, index) => <Card key={goal.id} style={styles.goalMini}>
        <Text style={styles.goalNumber}>0{index + 1}</Text><Text style={styles.focusTag}>{goal.focus.toUpperCase()}</Text><Text style={styles.goalMiniTitle}>{goal.title}</Text><ProgressBar value={goal.progress}/><View style={styles.goalMeta}><Text style={styles.goalPercent}>{goal.progress}%</Text><Text style={styles.goalTarget}>{goal.target}</Text></View>
      </Card>)}
    </ScrollView>
    <Card style={styles.networkPrompt}><View style={styles.promptTop}><View style={styles.liveDot}/><Text style={styles.promptLive}>18 ACTIVE IN THE TRADING FLOOR</Text></View><Text style={styles.promptTitle}>Which rule protected your capital this week?</Text><Text style={styles.promptMeta}>23 replies · Members only</Text><OutlineButton label="Enter the room" icon="arrow-forward" onPress={() => Alert.alert("The Trading Floor", "Room opened. Live WebSocket messages connect in the backend milestone.")}/></Card>
  </ScrollView>;
}

function GoalsScreen({ goals, nudgeGoal }: { goals: typeof initialGoals; nudgeGoal: (id: string) => void }) {
  const [filter, setFilter] = useState<"All" | Focus>("All");
  const [adding, setAdding] = useState(false);
  const visible = filter === "All" ? goals : goals.filter(goal => goal.focus === filter);
  return <ScrollView contentContainerStyle={styles.screen}>
    <ScreenIntro eyebrow="MOMENTUM SYSTEM" title="GOALS & STANDARDS" text="Direction without a system is only intention." />
    <View style={styles.filterRow}>{(["All","Business","Trading","Fitness"] as const).map(item => <Pressable key={item} onPress={() => setFilter(item)} style={[styles.filterChip, filter === item && styles.filterChipActive]}><Text style={[styles.filterText, filter === item && styles.filterTextActive]}>{item.toUpperCase()}</Text></Pressable>)}</View>
    {visible.map(goal => <Card key={goal.id} style={styles.fullGoal}>
      <View style={styles.fullGoalTop}><View style={styles.categoryIcon}><Ionicons name={goal.focus === "Business" ? "briefcase-outline" : goal.focus === "Trading" ? "trending-up" : "barbell-outline"} color={colors.gold} size={20}/></View><View style={{flex:1}}><Text style={styles.focusTag}>{goal.focus.toUpperCase()}</Text><Text style={styles.fullGoalTitle}>{goal.title}</Text></View><Text style={styles.fullGoalPercent}>{goal.progress}%</Text></View>
      <ProgressBar value={goal.progress}/><View style={styles.fullGoalBottom}><Text style={styles.goalTarget}>TARGET · {goal.target.toUpperCase()}</Text><Pressable onPress={() => nudgeGoal(goal.id)}><Text style={styles.logProgress}>+ LOG PROGRESS</Text></Pressable></View>
    </Card>)}
    {adding ? <Card style={styles.addCard}><Text style={styles.label}>NEW PRIVATE GOAL</Text><TextInput placeholder="What are you moving towards?" placeholderTextColor={colors.mutedDark} style={styles.inlineInput}/><GoldButton label="Save goal" onPress={() => { setAdding(false); Alert.alert("Goal saved", "The new goal is private by default."); }}/></Card> : <OutlineButton label="Create a private goal" icon="add" onPress={() => setAdding(true)}/>}
    <View style={styles.sectionHead}><View><Eyebrow>DAILY STANDARDS</Eyebrow><Text style={styles.sectionTitle}>CONSISTENCY ENGINE</Text></View></View>
    {initialMotions.map(item => <View key={item.id} style={styles.standardRow}><View style={styles.standardIcon}><Ionicons name={item.focus === "Business" ? "briefcase-outline" : item.focus === "Trading" ? "trending-up" : "barbell-outline"} color={colors.gold} size={17}/></View><View style={{flex:1}}><Text style={styles.standardTitle}>{item.title}</Text><Text style={styles.motionMeta}>{item.focus.toUpperCase()} · 7 DAY STREAK</Text></View><Ionicons name="checkmark-circle" color={colors.green} size={20}/></View>)}
  </ScrollView>;
}

function MomentumScreen({ xp, points, streak, reviewComplete, completeReview }: { xp:number; points:number; streak:number; reviewComplete:boolean; completeReview:()=>void }) {
  const level = getLevel(xp);
  const stage = getMomentumStage(points);
  const bonus = weeklyMomentumBonus(streak);
  const activity = [
    { title:"London watchlist reviewed", source:"Priority move", points:12, xp:5, icon:"trending-up" as const },
    { title:"Sales conversations completed", source:"Daily standard", points:8, xp:3, icon:"briefcase-outline" as const },
    { title:"2× bodyweight deadlift progress logged", source:"Goal progress", points:6, xp:5, icon:"barbell-outline" as const },
    ...(reviewComplete ? [{ title:"Weekly review completed", source:"Weekly review", points:10, xp:10, icon:"document-text-outline" as const }] : [])
  ];
  return <ScrollView contentContainerStyle={styles.screen}>
    <ScreenIntro eyebrow="PERMANENT PROGRESSION" title={`LEVEL ${level.level} · ${level.name.toUpperCase()}`} text="XP marks the work you have banked. It never resets." />
    <Card style={styles.levelCard}>
      <View style={styles.levelTop}><View><Text style={styles.levelXp}>{xp.toLocaleString()} XP</Text><Text style={styles.levelCaption}>{level.next ? `${level.xpToNext} XP TO ${level.next.name.toUpperCase()}` : "MAXIMUM LEVEL REACHED"}</Text></View><View style={styles.levelBadge}><Text style={styles.levelBadgeNumber}>{level.level}</Text></View></View>
      <ProgressBar value={level.progress}/><Text style={styles.levelProgressText}>{level.progress}% THROUGH THIS LEVEL</Text>
    </Card>

    <Card style={styles.momentumHero}>
      <View style={styles.momentumHeroHead}><View><Eyebrow>THIS WEEK</Eyebrow><Text style={styles.momentumHeroTitle}>BUILD THE BAR.</Text></View><Text style={styles.momentumHeroPoints}>{points}<Text style={styles.momentumHeroTotal}>/100</Text></Text></View>
      <View style={styles.momentumLargeTrack}><View style={[styles.momentumLargeFill,{width:`${points}%`}]} /></View>
      <View style={styles.stageRail}>{["IGNITION","BUILDING","MOVING","DRIVING","FULL MOTION"].map((name,index)=><View key={name} style={styles.stageItem}><View style={[styles.stageDot,index<=stage.index&&styles.stageDotActive]}/><Text style={[styles.stageName,index===stage.index&&styles.stageNameActive]}>{name}</Text></View>)}</View>
      <View style={styles.deadlineRow}><View><Text style={styles.deadlineLabel}>WEEK CLOSES IN</Text><Text style={styles.deadlineValue}>2D 06H 14M</Text></View><View style={styles.bonusBlock}><Text style={styles.deadlineLabel}>FULL-MOTION REWARD</Text><Text style={styles.bonusValue}>+{bonus} XP</Text></View></View>
      <Text style={styles.resetNote}><Ionicons name="refresh-outline" size={12}/> The bar resets Sunday at midnight. Fill it to bank Momentum XP and extend your streak.</Text>
    </Card>

    <View style={styles.momentumStats}>
      <Card style={styles.momentumStat}><Text style={styles.momentumStatValue}>{streak}</Text><Text style={styles.momentumStatLabel}>FULL WEEKS IN A ROW</Text></Card>
      <Card style={styles.momentumStat}><Text style={styles.momentumStatValue}>3</Text><Text style={styles.momentumStatLabel}>PILLARS ACTIVE</Text></Card>
      <Card style={styles.momentumStat}><Text style={styles.momentumStatValue}>2</Text><Text style={styles.momentumStatLabel}>BEST STREAK RANK</Text></Card>
    </View>

    <View style={styles.sectionHead}><View><Eyebrow>POINT SOURCES</Eyebrow><Text style={styles.sectionTitle}>WHAT MOVED THE BAR</Text></View></View>
    <Card style={styles.ledgerCard}>{activity.map((item,index)=><View key={item.title} style={[styles.ledgerRow,index>0&&styles.ledgerBorder]}><View style={styles.ledgerIcon}><Ionicons name={item.icon} color={colors.gold} size={17}/></View><View style={{flex:1}}><Text style={styles.ledgerTitle}>{item.title}</Text><Text style={styles.ledgerSource}>{item.source.toUpperCase()}</Text></View><View><Text style={styles.ledgerPoints}>+{item.points} MOM</Text><Text style={styles.ledgerXp}>+{item.xp} XP</Text></View></View>)}</Card>

    {!reviewComplete ? <GoldButton label="Complete weekly review · +10 momentum" icon="document-text-outline" onPress={completeReview}/> : <View style={styles.reviewDone}><Ionicons name="checkmark-circle" color={colors.green} size={19}/><Text style={styles.reviewDoneText}>WEEKLY REVIEW COMPLETE · REWARD BANKED</Text></View>}

    <View style={styles.sectionHead}><View><Eyebrow>LEVEL LADDER</Eyebrow><Text style={styles.sectionTitle}>THE FORWARD PATH</Text></View></View>
    <Card style={styles.ladder}>{LEVELS.map(item=><View key={item.level} style={styles.ladderRow}><View style={[styles.ladderNumber,item.level<=level.level&&styles.ladderNumberActive]}><Text style={[styles.ladderNumberText,item.level<=level.level&&styles.ladderNumberTextActive]}>{item.level}</Text></View><View style={{flex:1}}><Text style={[styles.ladderName,item.level===level.level&&styles.ladderCurrent]}>{item.name.toUpperCase()}</Text><Text style={styles.ladderXp}>{item.xp.toLocaleString()} XP</Text></View>{item.level<level.level?<Ionicons name="checkmark" color={colors.green} size={17}/>:item.level===level.level?<Text style={styles.youAreHere}>YOU ARE HERE</Text>:<Ionicons name="lock-closed-outline" color={colors.mutedDark} size={15}/>}</View>)}</Card>

    <View style={styles.sectionHead}><View><Eyebrow>RECENT WEEKS</Eyebrow><Text style={styles.sectionTitle}>MOMENTUM HISTORY</Text></View></View>
    {[["14–20 JUL","100","FULL MOTION","+150 XP"],["7–13 JUL","100","FULL MOTION","+125 XP"],["30 JUN–6 JUL","84","DRIVING","NO BONUS"]].map(([week,score,result,reward])=><View key={week} style={styles.historyRow}><Text style={styles.historyWeek}>{week}</Text><View style={{flex:1}}><ProgressBar value={Number(score)}/><Text style={styles.historyResult}>{result}</Text></View><Text style={[styles.historyReward,reward==="NO BONUS"&&styles.noBonus]}>{reward}</Text></View>)}

    <Card style={styles.rulesCard}><Eyebrow>HOW IT STAYS FAIR</Eyebrow><Text style={styles.rulesTitle}>MOMENTUM REWARDS CONSISTENCY, NOT TAPPING.</Text><Text style={styles.rulesText}>Every action has a daily cap. Reversing and repeating an action cannot earn points twice. Project and community rewards require meaningful contribution. The server closes each week in your account timezone and awards Momentum XP once.</Text></Card>
  </ScrollView>;
}

function NetworkScreen() {
  const [mode, setMode] = useState<"rooms" | "projects">("rooms");
  const [selectedRoom, setSelectedRoom] = useState<(typeof rooms)[number] | null>(null);
  const [message, setMessage] = useState("");
  const [posts, setPosts] = useState(["Process over prediction. My best trade today was the one I did not take.", "Risk stayed at 0.5%. Clean execution, clean review."]);
  const send = () => { if (message.trim()) { setPosts([...posts, message.trim()]); setMessage(""); } };
  return <ScrollView contentContainerStyle={styles.screen}>
    <ScreenIntro eyebrow="THE NETWORK" title="BUILD WITH PEOPLE IN MOTION" text="Useful conversations. Strong introductions. Shared standards." />
    <View style={styles.segment}><Pressable onPress={() => setMode("rooms")} style={[styles.segmentItem, mode==="rooms"&&styles.segmentActive]}><Text style={[styles.segmentText,mode==="rooms"&&styles.segmentTextActive]}>ROOMS</Text></Pressable><Pressable onPress={() => setMode("projects")} style={[styles.segmentItem,mode==="projects"&&styles.segmentActive]}><Text style={[styles.segmentText,mode==="projects"&&styles.segmentTextActive]}>PROJECTS</Text></Pressable></View>
    {mode === "rooms" ? rooms.map(room => <Pressable key={room.id} onPress={() => setSelectedRoom(room)}><Card style={styles.roomCard}><View style={styles.roomIcon}><Ionicons name={room.icon} color={colors.gold} size={21}/></View><View style={{flex:1}}><Text style={styles.roomTitle}>{room.title}</Text><Text style={styles.roomText}>{room.description}</Text><Text style={styles.roomMeta}>{room.active} ACTIVE NOW · {room.unread} NEW</Text></View><Ionicons name="arrow-forward" color={colors.gold} size={18}/></Card></Pressable>) :
      projects.map(project => <Pressable key={project.id} onPress={() => Alert.alert(project.title, `${project.meta}\n\nThis invitation-only workspace is private to its members.`)}><Card style={styles.projectCard}><View style={styles.projectTop}><Ionicons name="folder-outline" color={colors.gold} size={20}/><View style={{flex:1}}><Text style={styles.roomTitle}>{project.title}</Text><Text style={styles.roomMeta}>{project.meta.toUpperCase()}</Text></View><Text style={styles.projectPercent}>{project.progress}%</Text></View><ProgressBar value={project.progress}/></Card></Pressable>)}
    <Modal visible={!!selectedRoom} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setSelectedRoom(null)}>
      <View style={styles.modalRoot}><View style={styles.modalHead}><Pressable onPress={() => setSelectedRoom(null)}><Ionicons name="close" color={colors.text} size={25}/></Pressable><View><Text style={styles.modalTitle}>{selectedRoom?.title}</Text><Text style={styles.modalMeta}>{selectedRoom?.active} MEMBERS ACTIVE</Text></View><Ionicons name="people-outline" color={colors.gold} size={21}/></View>
      <ScrollView contentContainerStyle={styles.chatContent}>{posts.map((post,index)=><View key={`${post}-${index}`} style={styles.roomPost}><View style={styles.avatar}><Text style={styles.avatarText}>{index%2 ? "MC" : "PS"}</Text></View><View style={{flex:1}}><Text style={styles.postName}>{index%2 ? "Marcus Cole" : "Priya Shah"} <Text style={styles.postTime}>· {index+2}h</Text></Text><Text style={styles.postText}>{post}</Text><View style={styles.postActions}><Ionicons name="heart-outline" color={colors.muted} size={15}/><Text style={styles.postActionText}>{8+index}</Text><Ionicons name="chatbubble-outline" color={colors.muted} size={14}/><Text style={styles.postActionText}>Reply</Text></View></View></View>)}</ScrollView>
      <View style={styles.composer}><TextInput value={message} onChangeText={setMessage} placeholder="Add to the conversation…" placeholderTextColor={colors.mutedDark} style={styles.composerInput}/><Pressable onPress={send} style={styles.sendButton}><Ionicons name="arrow-up" color={colors.black} size={19}/></Pressable></View></View>
    </Modal>
  </ScrollView>;
}

function MessagesScreen() {
  const [selected, setSelected] = useState<(typeof conversations)[number] | null>(null);
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState<string[]>([]);
  return <View style={{flex:1}}><ScrollView contentContainerStyle={styles.screen}>
    <ScreenIntro eyebrow="PRIVATE CHANNELS" title="DIRECT MESSAGES" text="Private conversations for feedback, introductions and accountability." />
    <Pressable style={styles.searchBox}><Ionicons name="search" color={colors.muted} size={18}/><Text style={styles.searchText}>Search members and messages</Text></Pressable>
    {conversations.map(person => <Pressable key={person.id} onPress={() => setSelected(person)} style={styles.conversation}><View style={styles.avatarLarge}><Text style={styles.avatarLargeText}>{person.initials}</Text></View><View style={{flex:1}}><View style={styles.conversationTop}><Text style={styles.conversationName}>{person.name}</Text><Text style={styles.conversationTime}>{person.time}</Text></View><Text style={styles.conversationContext}>{person.context.toUpperCase()}</Text><Text style={styles.conversationPreview} numberOfLines={1}>{person.preview}</Text></View>{person.unread>0&&<View style={styles.unread}><Text style={styles.unreadText}>{person.unread}</Text></View>}</Pressable>)}
    <OutlineButton label="Start a private conversation" icon="create-outline" onPress={()=>Alert.alert("New message","Member search is ready to connect to the directory API.")}/>
    </ScrollView>
    <Modal visible={!!selected} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setSelected(null)}><View style={styles.modalRoot}><View style={styles.modalHead}><Pressable onPress={()=>setSelected(null)}><Ionicons name="chevron-back" color={colors.text} size={25}/></Pressable><View><Text style={styles.modalTitle}>{selected?.name}</Text><Text style={styles.modalMeta}>PRIVATE · {selected?.context.toUpperCase()}</Text></View><Ionicons name="information-circle-outline" color={colors.gold} size={22}/></View>
      <ScrollView contentContainerStyle={styles.directChat}><View style={styles.received}><Text style={styles.bubbleText}>{selected?.preview}</Text><Text style={styles.bubbleTime}>{selected?.time}</Text></View>{sent.map((text,index)=><View style={styles.sentBubble} key={`${text}-${index}`}><Text style={styles.sentBubbleText}>{text}</Text><Text style={styles.sentBubbleTime}>Now</Text></View>)}</ScrollView>
      <View style={styles.composer}><TextInput value={message} onChangeText={setMessage} placeholder="Private message…" placeholderTextColor={colors.mutedDark} style={styles.composerInput}/><Pressable onPress={()=>{if(message.trim()){setSent([...sent,message.trim()]);setMessage("");}}} style={styles.sendButton}><Ionicons name="arrow-up" color={colors.black} size={19}/></Pressable></View></View></Modal>
  </View>;
}

function ProfileScreen({ name, focuses, xp, onLogout }: { name:string; focuses:Focus[]; xp:number; onLogout:()=>void }) {
  const level = getLevel(xp);
  const [push, setPush] = useState(true);
  const [discoverable, setDiscoverable] = useState(true);
  const [progressPrivate, setProgressPrivate] = useState(true);
  return <ScrollView contentContainerStyle={styles.screen}>
    <ScreenIntro eyebrow="YOUR CONTROL" title="PROFILE & PRIVACY" text="Your identity inside Motion Only. Your data stays under your control." />
    <Card style={styles.profileCard}><View style={styles.profileAvatar}><Text style={styles.profileInitials}>{name.split(" ").map(part=>part[0]).join("").slice(0,2).toUpperCase()}</Text></View><Text style={styles.profileName}>{name}</Text><Text style={styles.profileMeta}>LEVEL {level.level} · {level.name.toUpperCase()} · {xp} XP</Text><View style={styles.focusPills}>{focuses.map(focus=><Text key={focus} style={styles.focusPill}>{focus.toUpperCase()}</Text>)}</View><OutlineButton label="Edit member profile" icon="create-outline" onPress={()=>Alert.alert("Profile","Profile editing is ready for the member API.")}/></Card>
    <View style={styles.sectionHead}><View><Eyebrow>PRIVACY DEFAULTS</Eyebrow><Text style={styles.sectionTitle}>YOU DECIDE WHAT MOVES</Text></View></View>
    <SettingRow icon="lock-closed-outline" title="Goals and progress private" text="Only shared when you choose" value={progressPrivate} onValueChange={setProgressPrivate}/>
    <SettingRow icon="people-outline" title="Discoverable by members" text="Never visible outside Motion Only" value={discoverable} onValueChange={setDiscoverable}/>
    <SettingRow icon="notifications-outline" title="Push notifications" text="Messages, invitations and commitments" value={push} onValueChange={setPush}/>
    <Pressable onPress={()=>Alert.alert("Network operations","128 members · 7 invitations pending · 2 moderation items")} style={styles.operations}><Ionicons name="shield-checkmark-outline" color={colors.gold} size={20}/><View style={{flex:1}}><Text style={styles.operationsTitle}>NETWORK OPERATIONS</Text><Text style={styles.operationsText}>Members, invitations, roles and moderation</Text></View><Ionicons name="chevron-forward" color={colors.muted} size={18}/></Pressable>
    <OutlineButton label="Sign out securely" icon="log-out-outline" onPress={onLogout}/>
    <Text style={styles.version}>MOTION ONLY · VERSION 0.1.0 · PRIVATE BETA</Text>
  </ScrollView>;
}

function ScreenIntro({ eyebrow, title, text }: { eyebrow:string; title:string; text:string }) {
  return <View style={styles.screenIntro}><Eyebrow>{eyebrow}</Eyebrow><Text style={styles.screenTitle}>{title}</Text><Text style={styles.screenText}>{text}</Text></View>;
}

function SettingRow({ icon, title, text, value, onValueChange }: {icon:keyof typeof Ionicons.glyphMap;title:string;text:string;value:boolean;onValueChange:(value:boolean)=>void}) {
  return <View style={styles.settingRow}><View style={styles.standardIcon}><Ionicons name={icon} color={colors.gold} size={18}/></View><View style={{flex:1}}><Text style={styles.settingTitle}>{title}</Text><Text style={styles.settingText}>{text}</Text></View><Switch value={value} onValueChange={onValueChange} trackColor={{false:colors.line,true:"#514628"}} thumbColor={value?colors.gold:colors.muted}/></View>;
}

const styles = StyleSheet.create({
  root:{flex:1,backgroundColor:colors.background},header:{height:93,paddingTop:48,paddingHorizontal:18,borderBottomWidth:1,borderBottomColor:colors.line,backgroundColor:colors.black,flexDirection:"row",alignItems:"center"},headerCenter:{flex:1,alignItems:"center"},headerBrand:{color:colors.text,fontWeight:"900",fontStyle:"italic",fontSize:14,letterSpacing:.8},headerSub:{color:colors.mutedDark,fontSize:6,letterSpacing:1.3,marginTop:2},headerButton:{width:38,height:38,alignItems:"center",justifyContent:"center"},dot:{position:"absolute",right:8,top:7,width:6,height:6,backgroundColor:colors.gold},screen:{paddingHorizontal:18,paddingTop:27,paddingBottom:40,gap:12},hero:{borderLeftWidth:3,borderLeftColor:colors.gold,paddingLeft:15,marginBottom:10},heroTitle:{color:colors.text,fontSize:34,lineHeight:33,fontWeight:"900",fontStyle:"italic",letterSpacing:-.3},heroText:{color:colors.muted,fontSize:11,marginTop:9},metricRow:{flexDirection:"row",gap:10},metricCard:{flex:1,minHeight:120},metricValue:{color:colors.text,fontSize:35,fontWeight:"900",fontStyle:"italic"},metricSmall:{color:colors.muted,fontSize:18},metricLabel:{color:colors.textSoft,fontSize:8,fontWeight:"800",letterSpacing:.8,marginTop:6},metricDelta:{color:colors.gold,fontSize:8,marginTop:9},weeklyMomentumCard:{borderColor:"#4A4028",backgroundColor:"#151510",gap:12},weeklyMomentumTop:{flexDirection:"row",justifyContent:"space-between",alignItems:"flex-start"},weeklyMomentumStage:{color:colors.text,fontSize:20,fontWeight:"900",fontStyle:"italic"},weeklyMomentumPoints:{color:colors.gold,fontSize:28,fontWeight:"900",fontStyle:"italic"},weeklyMomentumTotal:{color:colors.muted,fontSize:13},momentumTrack:{height:8,backgroundColor:"#292A27",overflow:"hidden"},momentumFill:{height:8,backgroundColor:colors.gold},weeklyMomentumBottom:{flexDirection:"row",justifyContent:"space-between",gap:8},weeklyMomentumHint:{flex:1,color:colors.muted,fontSize:6.5,lineHeight:10,fontWeight:"700",letterSpacing:.35},weeklyMomentumTime:{color:colors.textSoft,fontSize:7,fontWeight:"800",letterSpacing:.5},sectionHead:{flexDirection:"row",alignItems:"flex-end",justifyContent:"space-between",marginTop:14,marginBottom:2},sectionTitle:{color:colors.text,fontSize:20,fontWeight:"900",fontStyle:"italic",letterSpacing:.1},sectionCount:{color:colors.gold,fontWeight:"900",fontSize:14},motionCard:{paddingVertical:2},motion:{minHeight:68,flexDirection:"row",alignItems:"center",gap:12,paddingVertical:13},motionBorder:{borderTopWidth:1,borderTopColor:colors.line},check:{width:22,height:22,borderWidth:1,borderColor:colors.lineStrong,alignItems:"center",justifyContent:"center"},checkDone:{backgroundColor:colors.gold,borderColor:colors.gold},motionTitle:{color:colors.textSoft,fontSize:11,fontWeight:"700"},motionTitleDone:{color:colors.muted,textDecorationLine:"line-through"},motionMeta:{color:colors.muted,fontSize:7,letterSpacing:.6,marginTop:5},textLink:{color:colors.textSoft,fontSize:8,fontWeight:"800",letterSpacing:.5},goalRail:{gap:10,paddingRight:18},goalMini:{width:225,minHeight:160,position:"relative",overflow:"hidden"},goalNumber:{position:"absolute",right:7,bottom:-16,color:"#222527",fontSize:68,fontWeight:"900",fontStyle:"italic"},focusTag:{color:colors.gold,fontSize:7,fontWeight:"800",letterSpacing:1,marginBottom:8},goalMiniTitle:{color:colors.text,fontWeight:"800",fontSize:13,lineHeight:17,minHeight:53,maxWidth:170},goalMeta:{flexDirection:"row",justifyContent:"space-between",marginTop:9},goalPercent:{color:colors.text,fontWeight:"900",fontSize:11},goalTarget:{color:colors.muted,fontSize:7,letterSpacing:.5},networkPrompt:{marginTop:9,borderTopWidth:2,borderTopColor:colors.gold,gap:10},promptTop:{flexDirection:"row",alignItems:"center",gap:7},liveDot:{width:6,height:6,borderRadius:3,backgroundColor:colors.green},promptLive:{color:colors.muted,fontSize:7,letterSpacing:.7,fontWeight:"700"},promptTitle:{color:colors.text,fontWeight:"900",fontStyle:"italic",fontSize:22,lineHeight:24},promptMeta:{color:colors.muted,fontSize:8,marginBottom:4},screenIntro:{borderLeftWidth:3,borderLeftColor:colors.gold,paddingLeft:15,marginBottom:13},screenTitle:{color:colors.text,fontWeight:"900",fontStyle:"italic",fontSize:31,lineHeight:31},screenText:{color:colors.muted,fontSize:10,lineHeight:16,marginTop:9,maxWidth:330},filterRow:{flexDirection:"row",gap:6,marginBottom:3},filterChip:{paddingHorizontal:10,paddingVertical:8,borderWidth:1,borderColor:colors.line},filterChipActive:{borderColor:colors.gold,backgroundColor:colors.goldSoft},filterText:{color:colors.muted,fontWeight:"800",fontSize:7,letterSpacing:.5},filterTextActive:{color:colors.gold},fullGoal:{gap:13},fullGoalTop:{flexDirection:"row",alignItems:"center",gap:11},categoryIcon:{width:40,height:40,alignItems:"center",justifyContent:"center",backgroundColor:colors.goldSoft},fullGoalTitle:{color:colors.text,fontSize:13,fontWeight:"800",lineHeight:17},fullGoalPercent:{color:colors.text,fontWeight:"900",fontStyle:"italic",fontSize:19},fullGoalBottom:{flexDirection:"row",alignItems:"center",justifyContent:"space-between"},logProgress:{color:colors.gold,fontSize:8,fontWeight:"900",letterSpacing:.5},addCard:{gap:10,borderColor:"#4D4228"},label:{color:colors.gold,fontSize:8,fontWeight:"800",letterSpacing:1},inlineInput:{minHeight:46,borderWidth:1,borderColor:colors.lineStrong,color:colors.text,paddingHorizontal:12},standardRow:{minHeight:70,flexDirection:"row",alignItems:"center",gap:12,borderBottomWidth:1,borderBottomColor:colors.line},standardIcon:{width:39,height:39,backgroundColor:colors.goldSoft,alignItems:"center",justifyContent:"center"},standardTitle:{color:colors.textSoft,fontSize:11,fontWeight:"700"},levelCard:{gap:11,borderTopWidth:2,borderTopColor:colors.gold},levelTop:{flexDirection:"row",alignItems:"center",justifyContent:"space-between"},levelXp:{color:colors.text,fontSize:26,fontWeight:"900",fontStyle:"italic"},levelCaption:{color:colors.muted,fontSize:7,letterSpacing:.7,marginTop:4},levelBadge:{width:48,height:48,backgroundColor:colors.gold,alignItems:"center",justifyContent:"center"},levelBadgeNumber:{color:colors.black,fontSize:23,fontWeight:"900",fontStyle:"italic"},levelProgressText:{color:colors.muted,fontSize:6.5,letterSpacing:.6},momentumHero:{gap:16,borderColor:"#4A4028",backgroundColor:"#151510"},momentumHeroHead:{flexDirection:"row",alignItems:"flex-start",justifyContent:"space-between"},momentumHeroTitle:{color:colors.text,fontSize:25,fontWeight:"900",fontStyle:"italic"},momentumHeroPoints:{color:colors.gold,fontSize:37,fontWeight:"900",fontStyle:"italic"},momentumHeroTotal:{color:colors.muted,fontSize:16},momentumLargeTrack:{height:13,backgroundColor:"#292A27",overflow:"hidden"},momentumLargeFill:{height:13,backgroundColor:colors.gold},stageRail:{flexDirection:"row",justifyContent:"space-between"},stageItem:{width:"19%",alignItems:"center",gap:5},stageDot:{width:7,height:7,borderRadius:4,backgroundColor:colors.lineStrong},stageDotActive:{backgroundColor:colors.gold},stageName:{color:colors.mutedDark,fontSize:5.5,fontWeight:"800",letterSpacing:.25,textAlign:"center"},stageNameActive:{color:colors.gold},deadlineRow:{flexDirection:"row",justifyContent:"space-between",borderTopWidth:1,borderTopColor:"#373427",paddingTop:14},deadlineLabel:{color:colors.muted,fontSize:6.5,letterSpacing:.7,fontWeight:"700"},deadlineValue:{color:colors.text,fontSize:17,fontWeight:"900",marginTop:4},bonusBlock:{alignItems:"flex-end"},bonusValue:{color:colors.gold,fontSize:17,fontWeight:"900",marginTop:4},resetNote:{color:colors.muted,fontSize:7.5,lineHeight:12},momentumStats:{flexDirection:"row",gap:7},momentumStat:{flex:1,minHeight:95,padding:12},momentumStatValue:{color:colors.text,fontSize:25,fontWeight:"900",fontStyle:"italic"},momentumStatLabel:{color:colors.muted,fontSize:6.5,lineHeight:10,fontWeight:"700",letterSpacing:.4,marginTop:7},ledgerCard:{paddingVertical:2},ledgerRow:{minHeight:69,flexDirection:"row",alignItems:"center",gap:11,paddingVertical:12},ledgerBorder:{borderTopWidth:1,borderTopColor:colors.line},ledgerIcon:{width:37,height:37,backgroundColor:colors.goldSoft,alignItems:"center",justifyContent:"center"},ledgerTitle:{color:colors.textSoft,fontSize:10,fontWeight:"700"},ledgerSource:{color:colors.muted,fontSize:6.5,letterSpacing:.55,marginTop:4},ledgerPoints:{color:colors.gold,fontSize:8,fontWeight:"900",textAlign:"right"},ledgerXp:{color:colors.muted,fontSize:7,textAlign:"right",marginTop:4},reviewDone:{minHeight:48,borderWidth:1,borderColor:"#29402F",backgroundColor:"#111A14",flexDirection:"row",alignItems:"center",justifyContent:"center",gap:8},reviewDoneText:{color:colors.textSoft,fontSize:8,fontWeight:"800",letterSpacing:.45},ladder:{paddingVertical:4},ladderRow:{minHeight:59,flexDirection:"row",alignItems:"center",gap:11,borderBottomWidth:1,borderBottomColor:colors.line},ladderNumber:{width:29,height:29,borderWidth:1,borderColor:colors.lineStrong,alignItems:"center",justifyContent:"center"},ladderNumberActive:{backgroundColor:colors.gold,borderColor:colors.gold},ladderNumberText:{color:colors.muted,fontSize:10,fontWeight:"900"},ladderNumberTextActive:{color:colors.black},ladderName:{color:colors.muted,fontSize:10,fontWeight:"800",letterSpacing:.45},ladderCurrent:{color:colors.gold},ladderXp:{color:colors.mutedDark,fontSize:6.5,marginTop:3},youAreHere:{color:colors.gold,fontSize:6.5,fontWeight:"900",letterSpacing:.5},historyRow:{minHeight:64,flexDirection:"row",alignItems:"center",gap:12,borderBottomWidth:1,borderBottomColor:colors.line},historyWeek:{color:colors.textSoft,fontSize:8,fontWeight:"800",width:66},historyResult:{color:colors.muted,fontSize:6.5,letterSpacing:.5,marginTop:5},historyReward:{color:colors.gold,fontSize:8,fontWeight:"900",width:55,textAlign:"right"},noBonus:{color:colors.mutedDark},rulesCard:{marginTop:8,borderLeftWidth:3,borderLeftColor:colors.gold},rulesTitle:{color:colors.text,fontSize:14,fontWeight:"900",fontStyle:"italic",lineHeight:18},rulesText:{color:colors.muted,fontSize:8.5,lineHeight:14,marginTop:9},segment:{flexDirection:"row",backgroundColor:colors.black,padding:3,marginBottom:4},segmentItem:{flex:1,alignItems:"center",paddingVertical:10},segmentActive:{backgroundColor:colors.raised},segmentText:{color:colors.muted,fontWeight:"800",fontSize:8,letterSpacing:.8},segmentTextActive:{color:colors.gold},roomCard:{flexDirection:"row",alignItems:"center",gap:13,minHeight:102},roomIcon:{width:45,height:45,backgroundColor:colors.goldSoft,alignItems:"center",justifyContent:"center"},roomTitle:{color:colors.text,fontWeight:"900",fontStyle:"italic",fontSize:16},roomText:{color:colors.muted,fontSize:9,marginTop:4,lineHeight:13},roomMeta:{color:colors.gold,fontSize:7,fontWeight:"700",letterSpacing:.6,marginTop:7},projectCard:{gap:13},projectTop:{flexDirection:"row",alignItems:"center",gap:11},projectPercent:{color:colors.text,fontWeight:"900",fontSize:17},modalRoot:{flex:1,backgroundColor:colors.background},modalHead:{paddingTop:24,paddingHorizontal:18,paddingBottom:15,borderBottomWidth:1,borderBottomColor:colors.line,flexDirection:"row",alignItems:"center",justifyContent:"space-between"},modalTitle:{color:colors.text,fontWeight:"900",fontSize:15,textAlign:"center"},modalMeta:{color:colors.gold,fontSize:7,letterSpacing:.7,textAlign:"center",marginTop:3},chatContent:{padding:18,gap:22},roomPost:{flexDirection:"row",gap:11},avatar:{width:36,height:36,backgroundColor:colors.raised,alignItems:"center",justifyContent:"center"},avatarText:{color:colors.text,fontWeight:"800",fontSize:10},postName:{color:colors.textSoft,fontWeight:"800",fontSize:10},postTime:{color:colors.muted,fontWeight:"400"},postText:{color:colors.textSoft,fontSize:12,lineHeight:18,marginTop:7},postActions:{flexDirection:"row",alignItems:"center",gap:5,marginTop:10},postActionText:{color:colors.muted,fontSize:8,marginRight:7},composer:{padding:12,paddingBottom:28,borderTopWidth:1,borderTopColor:colors.line,flexDirection:"row",alignItems:"center",gap:9},composerInput:{flex:1,minHeight:44,backgroundColor:colors.surface,color:colors.text,paddingHorizontal:13,borderWidth:1,borderColor:colors.line},sendButton:{width:44,height:44,backgroundColor:colors.gold,alignItems:"center",justifyContent:"center"},searchBox:{minHeight:46,borderWidth:1,borderColor:colors.line,backgroundColor:colors.surface,flexDirection:"row",alignItems:"center",gap:10,paddingHorizontal:13,marginBottom:5},searchText:{color:colors.muted,fontSize:10},conversation:{minHeight:82,borderBottomWidth:1,borderBottomColor:colors.line,flexDirection:"row",alignItems:"center",gap:12},avatarLarge:{width:46,height:46,backgroundColor:colors.raised,alignItems:"center",justifyContent:"center"},avatarLargeText:{color:colors.text,fontWeight:"900",fontSize:12},conversationTop:{flexDirection:"row",justifyContent:"space-between"},conversationName:{color:colors.text,fontWeight:"800",fontSize:12},conversationTime:{color:colors.muted,fontSize:8},conversationContext:{color:colors.gold,fontSize:6,fontWeight:"800",letterSpacing:.7,marginTop:4},conversationPreview:{color:colors.muted,fontSize:9,marginTop:4},unread:{width:19,height:19,borderRadius:10,backgroundColor:colors.gold,alignItems:"center",justifyContent:"center"},unreadText:{color:colors.black,fontWeight:"900",fontSize:8},directChat:{padding:18,gap:12,flexGrow:1},received:{alignSelf:"flex-start",maxWidth:"82%",backgroundColor:colors.raised,padding:13},sentBubble:{alignSelf:"flex-end",maxWidth:"82%",backgroundColor:colors.gold,padding:13},bubbleText:{color:colors.textSoft,fontSize:12,lineHeight:17},sentBubbleText:{color:colors.black,fontSize:12,lineHeight:17},bubbleTime:{color:colors.muted,fontSize:7,marginTop:7},sentBubbleTime:{color:"#55451F",fontSize:7,marginTop:7},profileCard:{alignItems:"center",gap:9,borderTopWidth:2,borderTopColor:colors.gold},profileAvatar:{width:70,height:70,backgroundColor:colors.gold,alignItems:"center",justifyContent:"center"},profileInitials:{color:colors.black,fontSize:22,fontWeight:"900"},profileName:{color:colors.text,fontWeight:"900",fontStyle:"italic",fontSize:22},profileMeta:{color:colors.muted,fontSize:7,letterSpacing:.8},focusPills:{flexDirection:"row",gap:6,marginVertical:6},focusPill:{color:colors.gold,borderWidth:1,borderColor:"#4E4328",backgroundColor:colors.goldSoft,paddingHorizontal:8,paddingVertical:5,fontSize:7,fontWeight:"800"},settingRow:{minHeight:72,flexDirection:"row",alignItems:"center",gap:11,borderBottomWidth:1,borderBottomColor:colors.line},settingTitle:{color:colors.textSoft,fontSize:11,fontWeight:"700"},settingText:{color:colors.muted,fontSize:8,marginTop:4},operations:{minHeight:72,flexDirection:"row",alignItems:"center",gap:12,borderWidth:1,borderColor:"#493F29",backgroundColor:"#151510",padding:13,marginVertical:8},operationsTitle:{color:colors.text,fontWeight:"900",fontSize:10,letterSpacing:.6},operationsText:{color:colors.muted,fontSize:8,marginTop:4},version:{color:colors.mutedDark,textAlign:"center",fontSize:7,letterSpacing:.8,marginTop:13},tabBar:{height:82,paddingBottom:20,borderTopWidth:1,borderTopColor:colors.line,backgroundColor:colors.black,flexDirection:"row"},tab:{flex:1,alignItems:"center",justifyContent:"center",gap:4},tabIconActive:{position:"relative"},tabLabel:{color:colors.muted,fontSize:6.2,fontWeight:"700",letterSpacing:.15},tabLabelActive:{color:colors.gold},messageDot:{position:"absolute",right:-4,top:-2,width:6,height:6,borderRadius:3,backgroundColor:colors.gold}
});
