export type Focus = "Business" | "Trading" | "Fitness";

export type Goal = {
  id: string;
  title: string;
  focus: Focus;
  progress: number;
  target: string;
};

export type Motion = {
  id: string;
  title: string;
  focus: Focus;
  meta: string;
  complete: boolean;
};

export const initialMotions: Motion[] = [
  { id: "m1", title: "Review London session watchlist", focus: "Trading", meta: "Before 07:30", complete: true },
  { id: "m2", title: "10 quality sales conversations", focus: "Business", meta: "Before 17:00", complete: false },
  { id: "m3", title: "Upper body strength + Zone 2", focus: "Fitness", meta: "45 minutes", complete: false }
];

export const initialGoals: Goal[] = [
  { id: "g1", title: "Build a £25k monthly sales pipeline", focus: "Business", progress: 48, target: "30 Sep" },
  { id: "g2", title: "Trade 90 days without breaking risk rules", focus: "Trading", progress: 61, target: "31 Oct" },
  { id: "g3", title: "Deadlift twice my bodyweight", focus: "Fitness", progress: 72, target: "16 Nov" }
];

export const rooms = [
  { id: "r1", title: "The Trading Floor", description: "Process-first execution, reviews and risk.", active: 18, unread: 23, icon: "trending-up" as const },
  { id: "r2", title: "Business Builders", description: "Offers, sales, operations and accountability.", active: 9, unread: 11, icon: "briefcase-outline" as const },
  { id: "r3", title: "Performance Room", description: "Strength, conditioning, nutrition and recovery.", active: 12, unread: 7, icon: "barbell-outline" as const }
];

export const projects = [
  { id: "p1", title: "90-Day Risk Discipline", meta: "6 members · Day 34", progress: 38 },
  { id: "p2", title: "£25k Pipeline Sprint", meta: "4 members · £12.4k qualified", progress: 52 },
  { id: "p3", title: "12-Week Strength Standard", meta: "8 members · Week 5 of 12", progress: 41 }
];

export const conversations = [
  { id: "c1", name: "Marcus Cole", initials: "MC", preview: "Your invalidation level is clean.", time: "12m", unread: 2, context: "Trading" },
  { id: "c2", name: "Priya Shah", initials: "PS", preview: "I’ll make the two introductions.", time: "1h", unread: 0, context: "Business" },
  { id: "c3", name: "Leo Grant", initials: "LG", preview: "Heavy compounds at 08:00. Target loads added.", time: "3h", unread: 0, context: "Fitness" }
];
