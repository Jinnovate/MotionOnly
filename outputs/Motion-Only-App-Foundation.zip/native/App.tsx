import React, { useEffect, useState } from "react";
import { ActivityIndicator, StyleSheet, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import * as SecureStore from "expo-secure-store";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { AuthScreen } from "./src/screens/AuthScreen";
import { OnboardingScreen } from "./src/screens/OnboardingScreen";
import { MainApp } from "./src/screens/MainApp";
import { Focus } from "./src/data";
import { colors } from "./src/theme";

type Stage = "auth" | "onboarding" | "app";
type Profile = { name: string; email: string; focuses: Focus[] };

const SESSION_KEY = "motion-only-session";

export default function App() {
  const [ready, setReady] = useState(false);
  const [stage, setStage] = useState<Stage>("auth");
  const [email, setEmail] = useState("");
  const [profile, setProfile] = useState<Profile | null>(null);

  useEffect(() => {
    SecureStore.getItemAsync(SESSION_KEY).then(value => {
      if (value) {
        try {
          const restored = JSON.parse(value) as Profile;
          setProfile(restored);
          setStage("app");
        } catch {
          setStage("auth");
        }
      }
    }).finally(() => setReady(true));
  }, []);

  const finishOnboarding = async (data: { name: string; focuses: Focus[] }) => {
    const next = { ...data, email };
    setProfile(next);
    await SecureStore.setItemAsync(SESSION_KEY, JSON.stringify(next));
    setStage("app");
  };

  const logout = async () => {
    await SecureStore.deleteItemAsync(SESSION_KEY);
    setProfile(null);
    setEmail("");
    setStage("auth");
  };

  if (!ready) return <View style={styles.loading}><ActivityIndicator color={colors.gold}/><StatusBar style="light"/></View>;

  return (
    <SafeAreaProvider>
      <StatusBar style="light"/>
      {stage === "auth" && <AuthScreen onAuthenticated={value => { setEmail(value); setStage("onboarding"); }} />}
      {stage === "onboarding" && <OnboardingScreen email={email} onComplete={finishOnboarding} />}
      {stage === "app" && profile && <MainApp name={profile.name} focuses={profile.focuses} onLogout={logout} />}
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, backgroundColor: colors.black, alignItems: "center", justifyContent: "center" }
});
