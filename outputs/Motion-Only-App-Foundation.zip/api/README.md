# Motion Only API

Privacy-first modular-monolith foundation for the Motion Only mobile application.

## Included

- Single-use invitation acceptance
- Argon2 password authentication
- One-time, expiring magic links
- Redis-backed opaque sessions and logout
- Role-protected administration invitations
- Private goals and progress history
- Server-authoritative XP and level progression
- Weekly Momentum points, daily caps, idempotent rewards and settlement
- Momentum streaks, bonus XP, history, unlocks and private weekly reviews
- Authenticated room WebSockets
- PostgreSQL schema for profiles, privacy, habits, rooms, DMs, projects, achievements, notifications, files and audit events
- Local PostgreSQL, Redis and S3-compatible private storage services

## Local setup

1. Copy `.env.example` to `.env`.
2. Start `compose.yaml` with a Docker-compatible runtime.
3. Run `npm install`.
4. Run `npm run dev`.

The production email adapter, push provider and managed storage credentials must be supplied before external beta distribution.
