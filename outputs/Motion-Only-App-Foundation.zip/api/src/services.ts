import { createHash, randomBytes } from "node:crypto";
import { Pool, PoolClient } from "pg";
import { Redis } from "ioredis";
import { config } from "./config.js";

export const db = new Pool({
  connectionString: config.DATABASE_URL,
  max: 15,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000
});

export const redis = new Redis(config.REDIS_URL, {
  maxRetriesPerRequest: 2,
  enableReadyCheck: true,
  lazyConnect: true
});

export type Session = {
  userId: string;
  email: string;
  role: "member" | "moderator" | "admin";
};

export function hashOpaqueToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export function newOpaqueToken(bytes = 32) {
  return randomBytes(bytes).toString("base64url");
}

export async function createSession(session: Session) {
  const token = newOpaqueToken();
  await redis.set(`session:${hashOpaqueToken(token)}`, JSON.stringify(session), "EX", config.SESSION_TTL_SECONDS);
  return token;
}

export async function readSession(token?: string): Promise<Session | null> {
  if (!token) return null;
  const value = await redis.get(`session:${hashOpaqueToken(token)}`);
  if (!value) return null;
  return JSON.parse(value) as Session;
}

export async function revokeSession(token: string) {
  await redis.del(`session:${hashOpaqueToken(token)}`);
}

export async function transaction<T>(work: (client: PoolClient) => Promise<T>) {
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    const result = await work(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
