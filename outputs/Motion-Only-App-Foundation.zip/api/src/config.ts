import "dotenv/config";
import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().positive().default(4000),
  DATABASE_URL: z.string().min(1).default("postgres://motion:motion@localhost:5432/motion_only"),
  REDIS_URL: z.string().min(1).default("redis://localhost:6379"),
  APP_DEEP_LINK: z.string().min(1).default("motiononly://auth"),
  SESSION_TTL_SECONDS: z.coerce.number().int().positive().default(2_592_000),
  MAGIC_LINK_TTL_SECONDS: z.coerce.number().int().positive().default(900)
});

export const config = schema.parse(process.env);
