import { randomUUID } from "node:crypto";
import Fastify, { FastifyRequest } from "fastify";
import cors from "@fastify/cors";
import rateLimit from "@fastify/rate-limit";
import sensible from "@fastify/sensible";
import { hash, verify } from "@node-rs/argon2";
import { z } from "zod";
import { WebSocket, WebSocketServer } from "ws";
import { config } from "./config.js";
import { createSession, db, hashOpaqueToken, newOpaqueToken, readSession, redis, revokeSession, Session, transaction } from "./services.js";

const app = Fastify({ logger: { redact: ["req.headers.authorization", "body.password", "body.token"] } });
await app.register(cors, { origin: false });
await app.register(rateLimit, { max: 120, timeWindow: "1 minute" });
await app.register(sensible);

function bearer(request: FastifyRequest) {
  const header = request.headers.authorization;
  return header?.startsWith("Bearer ") ? header.slice(7) : undefined;
}

async function requireSession(request: FastifyRequest) {
  const session = await readSession(bearer(request));
  if (!session) throw app.httpErrors.unauthorized("A valid session is required");
  return session;
}

app.get("/health", async () => {
  await Promise.all([db.query("SELECT 1"), redis.ping()]);
  return { status: "ok", service: "motion-only-api" };
});

app.post("/v1/auth/accept-invite", { config: { rateLimit: { max: 10, timeWindow: "15 minutes" } } }, async (request, reply) => {
  const body = z.object({
    inviteCode: z.string().min(8),
    email: z.email(),
    password: z.string().min(8).max(128),
    name: z.string().min(2).max(80)
  }).parse(request.body);
  const email = body.email.trim().toLowerCase();
  const inviteHash = hashOpaqueToken(body.inviteCode.trim());
  const passwordHash = await hash(body.password);

  const user = await transaction(async client => {
    const invite = await client.query<{ id:string; role:Session["role"] }>(
      `SELECT id, role FROM invitations
       WHERE token_hash=$1 AND lower(email)=lower($2) AND accepted_at IS NULL
         AND revoked_at IS NULL AND expires_at > now()
       FOR UPDATE`,
      [inviteHash, email]
    );
    if (!invite.rowCount) throw app.httpErrors.forbidden("Invitation is invalid or expired");
    const existing = await client.query("SELECT id FROM users WHERE lower(email)=lower($1)", [email]);
    if (existing.rowCount) throw app.httpErrors.conflict("An account already exists for this email");
    const id = randomUUID();
    await client.query(
      "INSERT INTO users (id,email,password_hash,status) VALUES ($1,$2,$3,'active')",
      [id, email, passwordHash]
    );
    await client.query(
      "INSERT INTO profiles (user_id,display_name) VALUES ($1,$2)",
      [id, body.name.trim()]
    );
    await client.query(
      "INSERT INTO user_roles (user_id,role) VALUES ($1,$2)",
      [id, invite.rows[0]!.role]
    );
    await client.query(
      "UPDATE invitations SET accepted_at=now(), accepted_by=$1 WHERE id=$2",
      [id, invite.rows[0]!.id]
    );
    return { id, email, role: invite.rows[0]!.role };
  });
  const token = await createSession({ userId:user.id, email:user.email, role:user.role });
  return reply.code(201).send({ token, user: { id:user.id, email:user.email, role:user.role } });
});

app.post("/v1/auth/password", { config: { rateLimit: { max: 8, timeWindow: "15 minutes" } } }, async request => {
  const body = z.object({ email:z.email(), password:z.string().min(8).max(128) }).parse(request.body);
  const result = await db.query<{id:string;email:string;password_hash:string;role:Session["role"]}>(
    `SELECT u.id,u.email,u.password_hash,coalesce(ur.role,'member') role
     FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.id
     WHERE lower(u.email)=lower($1) AND u.status='active'`,
    [body.email.trim()]
  );
  const user = result.rows[0];
  if (!user || !(await verify(user.password_hash, body.password))) throw app.httpErrors.unauthorized("Email or password is incorrect");
  const token = await createSession({ userId:user.id, email:user.email, role:user.role });
  return { token, user: { id:user.id, email:user.email, role:user.role } };
});

app.post("/v1/auth/magic-link", { config: { rateLimit: { max: 5, timeWindow: "15 minutes" } } }, async request => {
  const body = z.object({ email:z.email() }).parse(request.body);
  const result = await db.query<{id:string;email:string}>("SELECT id,email FROM users WHERE lower(email)=lower($1) AND status='active'", [body.email.trim()]);
  const user = result.rows[0];
  if (user) {
    const token = newOpaqueToken();
    await redis.set(`magic:${hashOpaqueToken(token)}`, user.id, "EX", config.MAGIC_LINK_TTL_SECONDS);
    const link = `${config.APP_DEEP_LINK}?token=${encodeURIComponent(token)}`;
    if (config.NODE_ENV === "development") return { accepted:true, developmentLink:link };
    // Production delivery is intentionally delegated to the configured transactional email adapter.
  }
  return { accepted:true };
});

app.post("/v1/auth/magic-link/verify", async request => {
  const body = z.object({ token:z.string().min(20) }).parse(request.body);
  const key = `magic:${hashOpaqueToken(body.token)}`;
  const userId = await redis.getdel(key);
  if (!userId) throw app.httpErrors.unauthorized("Magic link is invalid or expired");
  const result = await db.query<{id:string;email:string;role:Session["role"]}>(
    `SELECT u.id,u.email,coalesce(ur.role,'member') role FROM users u
     LEFT JOIN user_roles ur ON ur.user_id=u.id WHERE u.id=$1 AND u.status='active'`,
    [userId]
  );
  const user = result.rows[0];
  if (!user) throw app.httpErrors.unauthorized("Account is not active");
  const token = await createSession({ userId:user.id, email:user.email, role:user.role });
  return { token, user };
});

app.post("/v1/auth/logout", async request => {
  const token = bearer(request);
  if (token) await revokeSession(token);
  return { success:true };
});

app.get("/v1/me", async request => {
  const session = await requireSession(request);
  const result = await db.query(
    `SELECT u.id,u.email,p.display_name,p.bio,p.focuses,p.avatar_key,ps.profile_visibility,
            ps.progress_visibility,ps.messaging_permission
     FROM users u JOIN profiles p ON p.user_id=u.id
     JOIN privacy_settings ps ON ps.user_id=u.id WHERE u.id=$1`,
    [session.userId]
  );
  return { ...result.rows[0], role:session.role };
});

app.get("/v1/goals", async request => {
  const session = await requireSession(request);
  const result = await db.query(
    `SELECT id,title,focus,progress,target_date,status,created_at
     FROM goals WHERE owner_id=$1 AND deleted_at IS NULL ORDER BY created_at DESC`,
    [session.userId]
  );
  return { items:result.rows };
});

app.post("/v1/goals", async (request, reply) => {
  const session = await requireSession(request);
  const body = z.object({ title:z.string().min(2).max(180), focus:z.enum(["Business","Trading","Fitness"]), targetDate:z.iso.date().optional() }).parse(request.body);
  const id = randomUUID();
  const result = await db.query(
    `INSERT INTO goals (id,owner_id,title,focus,target_date,visibility)
     VALUES ($1,$2,$3,$4,$5,'private') RETURNING *`,
    [id,session.userId,body.title.trim(),body.focus,body.targetDate ?? null]
  );
  return reply.code(201).send(result.rows[0]);
});

app.patch("/v1/goals/:id/progress", async request => {
  const session = await requireSession(request);
  const params = z.object({ id:z.uuid() }).parse(request.params);
  const body = z.object({ progress:z.number().int().min(0).max(100), note:z.string().max(1000).optional() }).parse(request.body);
  return transaction(async client => {
    const updated = await client.query(
      `UPDATE goals SET progress=$1,updated_at=now() WHERE id=$2 AND owner_id=$3 AND deleted_at IS NULL RETURNING *`,
      [body.progress,params.id,session.userId]
    );
    if (!updated.rowCount) throw app.httpErrors.notFound("Goal not found");
    await client.query("INSERT INTO goal_updates (id,goal_id,user_id,progress,note) VALUES ($1,$2,$3,$4,$5)", [randomUUID(),params.id,session.userId,body.progress,body.note ?? null]);
    const reward = await client.query(
      "SELECT * FROM award_progress_event($1,'goal_progress','goal',$2,$3,5,6,3)",
      [session.userId,params.id,`goal:${params.id}:progress:${body.progress}`]
    );
    return { ...updated.rows[0], progression:reward.rows[0] };
  });
});

app.get("/v1/progression", async request => {
  const session = await requireSession(request);
  const [profile,week,events,history,levels] = await Promise.all([
    db.query(
      `SELECT lifetime_xp,current_level,momentum_streak,best_momentum_streak
       FROM progression_profiles WHERE user_id=$1`,
      [session.userId]
    ),
    db.query(
      `SELECT week_start,points,status,bonus_xp
       FROM momentum_weeks WHERE user_id=$1 AND week_start=local_week_start($1)
       LIMIT 1`,
      [session.userId]
    ),
    db.query(
      `SELECT event_type,source_type,xp_points,momentum_points,occurred_at,metadata
       FROM progression_events WHERE user_id=$1 ORDER BY occurred_at DESC LIMIT 25`,
      [session.userId]
    ),
    db.query(
      `SELECT week_start,points,status,bonus_xp
       FROM momentum_weeks WHERE user_id=$1 ORDER BY week_start DESC LIMIT 8`,
      [session.userId]
    ),
    db.query("SELECT level,name,xp_required FROM level_definitions ORDER BY level")
  ]);
  return {
    profile:profile.rows[0] ?? {lifetime_xp:0,current_level:1,momentum_streak:0,best_momentum_streak:0},
    week:week.rows[0] ?? {week_start:null,points:0,status:"building",bonus_xp:0},
    events:events.rows,
    history:history.rows,
    levels:levels.rows
  };
});

app.post("/v1/progression/weekly-review", async request => {
  const session = await requireSession(request);
  const body = z.object({
    reflection:z.string().min(20).max(4000),
    wins:z.array(z.string().min(2).max(300)).max(5).default([]),
    nextWeekFocus:z.string().min(2).max(500)
  }).parse(request.body);
  const week = await db.query<{week_start:string}>("SELECT local_week_start($1) week_start",[session.userId]);
  const weekStart = week.rows[0]!.week_start;
  const reward = await transaction(async client => {
    await client.query(
      `INSERT INTO weekly_reviews(user_id,week_start,reflection,wins,next_week_focus)
       VALUES($1,$2,$3,$4,$5)
       ON CONFLICT(user_id,week_start) DO UPDATE SET
         reflection=excluded.reflection,wins=excluded.wins,next_week_focus=excluded.next_week_focus,updated_at=now()`,
      [session.userId,weekStart,body.reflection,JSON.stringify(body.wins),body.nextWeekFocus]
    );
    return client.query(
      `SELECT * FROM award_progress_event($1,'weekly_review','momentum_week',NULL,$2,10,10,1)`,
      [session.userId,`weekly-review:${weekStart}`]
    );
  });
  await db.query(
    `INSERT INTO audit_log(actor_id,action,target_type,metadata)
     VALUES($1,'weekly_review.completed','momentum_week',$2)`,
    [session.userId,{weekStart}]
  );
  return { weekStart, progression:reward.rows[0] };
});

app.post("/v1/admin/invitations", async (request, reply) => {
  const session = await requireSession(request);
  if (session.role !== "admin") throw app.httpErrors.forbidden("Administrator role is required");
  const body = z.object({ email:z.email(), role:z.enum(["member","moderator","admin"]).default("member"), expiresInDays:z.number().int().min(1).max(30).default(7) }).parse(request.body);
  const token = newOpaqueToken(24);
  await db.query(
    `INSERT INTO invitations (id,email,token_hash,role,invited_by,expires_at)
     VALUES ($1,$2,$3,$4,$5,now()+($6 || ' days')::interval)`,
    [randomUUID(),body.email.trim().toLowerCase(),hashOpaqueToken(token),body.role,session.userId,body.expiresInDays]
  );
  return reply.code(201).send({ inviteCode:token, email:body.email, expiresInDays:body.expiresInDays });
});

type LiveSocket = WebSocket & { session?:Session; rooms?:Set<string> };
const wss = new WebSocketServer({ noServer:true });
app.server.on("upgrade", async (request, socket, head) => {
  const url = new URL(request.url ?? "/", "http://localhost");
  if (url.pathname !== "/v1/realtime") return;
  const session = await readSession(url.searchParams.get("token") ?? undefined);
  if (!session) return socket.destroy();
  wss.handleUpgrade(request,socket,head,ws => {
    const live = ws as LiveSocket;
    live.session=session; live.rooms=new Set();
    wss.emit("connection",live,request);
  });
});
wss.on("connection",(ws:LiveSocket) => {
  ws.send(JSON.stringify({type:"ready"}));
  ws.on("message",async raw => {
    try {
      const payload = z.discriminatedUnion("type",[
        z.object({type:z.literal("subscribe"),roomId:z.uuid()}),
        z.object({type:z.literal("room.message"),roomId:z.uuid(),body:z.string().min(1).max(4000)})
      ]).parse(JSON.parse(raw.toString()));
      if (payload.type === "subscribe") {
        const access = await db.query("SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2",[payload.roomId,ws.session!.userId]);
        if (access.rowCount) ws.rooms!.add(payload.roomId);
        return;
      }
      const access = await db.query("SELECT 1 FROM room_members WHERE room_id=$1 AND user_id=$2",[payload.roomId,ws.session!.userId]);
      if (!access.rowCount) return;
      const message = {type:"room.message",id:randomUUID(),roomId:payload.roomId,userId:ws.session!.userId,body:payload.body,createdAt:new Date().toISOString()};
      await db.query("INSERT INTO room_messages (id,room_id,sender_id,body) VALUES ($1,$2,$3,$4)",[message.id,message.roomId,message.userId,message.body]);
      wss.clients.forEach(client => { const peer=client as LiveSocket;if(peer.readyState===WebSocket.OPEN&&peer.rooms?.has(payload.roomId))peer.send(JSON.stringify(message)); });
    } catch {
      ws.send(JSON.stringify({type:"error",code:"INVALID_MESSAGE"}));
    }
  });
});

app.addHook("onClose",async()=>{await Promise.all([db.end(),redis.quit()]);wss.close();});
await redis.connect();
await app.listen({port:config.PORT,host:"0.0.0.0"});
