# Common Ground

Motion Only is a privacy-first, invite-only performance network.

The repository now contains three deliverables:

- `native/`: the iPhone and Android Expo application
- `api/`: the TypeScript modular-monolith service and PostgreSQL schema
- the original web prototype, retained as the visual reference

## Product architecture

The interface is structured for a modular monolith: identity and access, onboarding,
profiles, goals and habits, messaging, projects, achievements, notifications, and
administration are distinct product modules behind one application boundary.

The production implementation is designed for PostgreSQL as the durable store,
Redis for sessions/presence/queues, private object storage for evidence and files,
and WebSockets for rooms, direct messages, presence, and notifications. Every
goal, progress record, project asset, and achievement attachment should use
owner-only access by default with explicit, auditable sharing grants.

## Local development

See `native/README.md` and `api/README.md` for app and service setup.
